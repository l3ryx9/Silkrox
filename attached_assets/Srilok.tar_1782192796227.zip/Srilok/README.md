# Srilok — Application Android Sécurisée

Application Android professionnelle avec architecture MVVM, chiffrement AES-256-GCM, portefeuille Bitcoin et messagerie E2EE.

## Stack technique

| Composant | Technologie |
|---|---|
| Langage | Kotlin |
| UI | Jetpack Compose |
| Architecture | MVVM + Repository |
| DI | Hilt |
| Base de données | Room + EncryptedSharedPreferences |
| Réseau | Retrofit + OkHttp |
| Chiffrement | AES-256-GCM + Android Keystore |
| Messagerie | E2EE inspiré Signal (ECDH + AES-GCM) |
| Obfuscation | R8/ProGuard avancé |
| Tests | JUnit4 + MockK + Turbine |

## Couleurs

- **Fond** : `#000000` (Noir profond)
- **Accent** : `#C89B00` (Or/Doré)

## Architecture

```
app/
├── di/                    Modules Hilt (Network, Database, Repository, App)
├── data/
│   ├── local/             Room Database + DAOs + Entités
│   ├── remote/            APIs Retrofit + DTOs
│   └── repository/        Implémentations des repositories
├── domain/
│   ├── model/             Modèles métier
│   └── usecase/           Cas d'usage (extensible)
├── presentation/
│   ├── navigation/        NavGraph complet
│   ├── ui/
│   │   ├── theme/         Couleurs, Typographie, Formes
│   │   └── screens/       Tous les écrans Compose
│   ├── viewmodel/         ViewModels (Auth, Product, Wallet, Message, Order)
│   └── service/           SessionMonitorService
└── security/              CryptoManager, E2EEManager, EmulatorDetector, IntegrityChecker
```

## Fonctionnalités implémentées

### Authentification
- [x] Inscription avec vérification de force du mot de passe
- [x] Connexion avec sessions chiffrées (EncryptedSharedPreferences)
- [x] Déconnexion automatique après inactivité (15 min)
- [x] Fingerprint d'appareil anti-bruteforce

### Portefeuille Bitcoin
- [x] Affichage adresse + solde BTC
- [x] Historique des transactions
- [x] QR Code de paiement (ZXing)
- [x] Polling en temps réel du statut des paiements

### Messagerie E2EE
- [x] Échange de clés ECDH
- [x] Chiffrement AES-256-GCM par message
- [x] Perfect Forward Secrecy (clés éphémères)
- [x] Messages stockés chiffrés en base locale

### Marketplace
- [x] Catalogue avec grille
- [x] Recherche en temps réel
- [x] Détail produit avec galerie
- [x] Panier + paiement Bitcoin

### Administration
- [x] Tableau de bord avec statistiques
- [x] Gestion des commandes avec filtres
- [x] Gestion des utilisateurs
- [x] Gestion des annonces (CRUD)
- [x] Annonces système

### Sécurité
- [x] Détection émulateur (score multi-critères)
- [x] Vérification intégrité APK (signature SHA-256)
- [x] Certificate Pinning OkHttp
- [x] Network Security Config (no cleartext)
- [x] Backup désactivé (data_extraction_rules.xml)
- [x] ProGuard/R8 avec repackaging agressif
- [x] Android Keystore pour la clé maître AES-256-GCM
- [x] EncryptedSharedPreferences pour les tokens
- [x] Détection de débogueur

## Installation et compilation

### Prérequis
- Android Studio Hedgehog (2023.1.1) ou supérieur
- JDK 17
- Android SDK 35

### Étapes

1. Ouvrir le projet dans Android Studio :
   ```
   File → Open → sélectionner le dossier Srilok/
   ```

2. Configurer votre backend (modifier `buildConfigField` dans `app/build.gradle.kts`) :
   ```kotlin
   buildConfigField("String", "API_BASE_URL", "\"https://votre-api.com/v1/\"")
   buildConfigField("String", "API_CERT_SHA256", "\"sha256/VOTRE_SHA256_ICI=\"")
   ```

3. Remplacer la signature dans `security/IntegrityChecker.kt` :
   ```kotlin
   private const val EXPECTED_SIGNATURE_SHA256 = "votre_sha256_ici"
   ```

4. Mettre à jour le certificate pinning dans `xml/network_security_config.xml`

5. Compiler et installer :
   ```bash
   ./gradlew assembleDebug
   ./gradlew installDebug
   ```

### Build de production
```bash
./gradlew assembleRelease
```

## Push vers GitHub

```bash
# Dans le dossier android/Srilok/
git init
git add .
git commit -m "feat: initial Srilok Android project"
git remote add origin https://github.com/VOTRE_USERNAME/Silkrox.git
git branch -M main
git push -u origin main
```

> **Important** : Ne commitez jamais de fichier `.keystore`, `local.properties` ou `google-services.json`. Ces fichiers sont déjà dans `.gitignore`.

## Tests

```bash
# Tests unitaires
./gradlew test

# Tests d'instrumentation
./gradlew connectedAndroidTest
```

## Backend REST requis

L'application nécessite un backend REST avec les endpoints suivants :

| Route | Méthode | Description |
|---|---|---|
| `/auth/register` | POST | Inscription |
| `/auth/login` | POST | Connexion |
| `/auth/logout` | POST | Déconnexion |
| `/auth/refresh` | POST | Refresh token |
| `/products` | GET/POST | Liste / Création |
| `/products/{id}` | GET/PATCH/DELETE | Détail / Modification |
| `/orders` | GET/POST | Commandes |
| `/wallet` | GET | Portefeuille |
| `/wallet/transactions` | GET | Transactions |
| `/wallet/payment-status/{id}` | GET | Statut paiement |
| `/conversations` | GET | Conversations |
| `/messages` | POST | Envoyer message |
| `/keys/exchange` | POST | Échange de clés E2EE |
| `/admin/*` | GET/POST | Endpoints admin |

## Notes de sécurité

1. **Ne jamais** stocker de secrets en clair dans le code source
2. Remplacer le SHA-256 de la signature avant le déploiement
3. Mettre à jour le certificate pinning à chaque renouvellement de certificat
4. Le chiffrement Keystore ne fonctionne que sur appareil réel (pas émulateur)
5. Activer la détection d'émulateur en production uniquement
