package com.srilok.app.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.srilok.app.data.local.Converters

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String,
    val username: String,
    val role: String,
    val walletAddress: String,
    val publicKeyEncrypted: ByteArray,
    val createdAt: Long,
    val lastSeen: Long
) {
    override fun equals(other: Any?) = other is UserEntity && id == other.id
    override fun hashCode() = id.hashCode()
}

@Entity(tableName = "products")
@TypeConverters(Converters::class)
data class ProductEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val price: Double,
    val categoryId: String,
    val sellerId: String,
    val imagesJson: String,
    val quantity: Int,
    val status: String,
    val viewCount: Int,
    val orderCount: Int,
    val featured: Boolean,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val id: String,
    val productId: String,
    val buyerId: String,
    val sellerId: String,
    val quantity: Int,
    val totalBtc: Double,
    val paymentAddress: String,
    val status: String,
    val txHash: String?,
    val confirmations: Int,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val senderId: String,
    val encryptedContent: ByteArray,
    val iv: ByteArray,
    val isRead: Boolean,
    val timestamp: Long
) {
    override fun equals(other: Any?) = other is MessageEntity && id == other.id
    override fun hashCode() = id.hashCode()
}

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey val id: String,
    val participantIdsJson: String,
    val lastMessageTimestamp: Long?,
    val unreadCount: Int,
    val sessionKeyEncrypted: ByteArray
) {
    override fun equals(other: Any?) = other is ConversationEntity && id == other.id
    override fun hashCode() = id.hashCode()
}

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val txHash: String,
    val walletAddress: String,
    val amount: Double,
    val confirmations: Int,
    val type: String,
    val timestamp: Long
)
