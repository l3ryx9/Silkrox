package com.srilok.app.presentation.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val SrilokBlack = Color(0xFF000000)
val SrilokGold = Color(0xFFC89B00)
val SrilokGoldLight = Color(0xFFE8B800)
val SrilokGoldDark = Color(0xFF8A6A00)
val SrilokSurface = Color(0xFF0D0D0D)
val SrilokSurface2 = Color(0xFF1A1A1A)
val SrilokSurface3 = Color(0xFF242424)
val SrilokOnSurface = Color(0xFFEEEEEE)
val SrilokOnSurfaceMuted = Color(0xFF888888)
val SrilokError = Color(0xFFCF6679)
val SrilokSuccess = Color(0xFF4CAF50)
val SrilokWarning = Color(0xFFFF9800)

private val DarkColorScheme = darkColorScheme(
    primary = SrilokGold,
    onPrimary = SrilokBlack,
    primaryContainer = SrilokGoldDark,
    onPrimaryContainer = SrilokGoldLight,
    secondary = SrilokGoldLight,
    onSecondary = SrilokBlack,
    background = SrilokBlack,
    onBackground = SrilokOnSurface,
    surface = SrilokSurface,
    onSurface = SrilokOnSurface,
    surfaceVariant = SrilokSurface2,
    onSurfaceVariant = SrilokOnSurfaceMuted,
    error = SrilokError,
    onError = Color.White,
    outline = SrilokGoldDark,
)

@Composable
fun SrilokTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = SrilokTypography,
        shapes = SrilokShapes,
        content = content
    )
}
