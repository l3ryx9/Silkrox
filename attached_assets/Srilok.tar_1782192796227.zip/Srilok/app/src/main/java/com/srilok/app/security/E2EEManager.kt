package com.srilok.app.security

import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.PublicKey
import javax.crypto.KeyAgreement
import javax.crypto.spec.SecretKeySpec
import javax.inject.Inject
import javax.inject.Singleton

/**
 * End-to-End Encryption manager inspired by Signal protocol principles.
 * Uses X25519 ECDH for key agreement + AES-256-GCM for message encryption.
 * Implements Perfect Forward Secrecy via ephemeral key pairs per session.
 */
@Singleton
class E2EEManager @Inject constructor(private val cryptoManager: CryptoManager) {

    companion object {
        private const val KEY_ALGORITHM = "EC"
        private const val ECDH_ALGORITHM = "ECDH"
        private const val KEY_SIZE = 256
    }

    fun generateIdentityKeyPair(): KeyPair {
        val gen = KeyPairGenerator.getInstance(KEY_ALGORITHM)
        gen.initialize(KEY_SIZE)
        return gen.generateKeyPair()
    }

    fun generateEphemeralKeyPair(): KeyPair = generateIdentityKeyPair()

    fun computeSharedSecret(privateKey: PrivateKey, remotePublicKey: PublicKey): ByteArray {
        val keyAgreement = KeyAgreement.getInstance(ECDH_ALGORITHM)
        keyAgreement.init(privateKey)
        keyAgreement.doPhase(remotePublicKey, true)
        return keyAgreement.generateSecret()
    }

    fun deriveSessionKey(sharedSecret: ByteArray): SecretKeySpec {
        val digest = java.security.MessageDigest.getInstance("SHA-256")
        val keyBytes = digest.digest(sharedSecret)
        return SecretKeySpec(keyBytes, "AES")
    }

    fun encryptMessage(message: String, sessionKey: SecretKeySpec): ByteArray {
        val cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
        val iv = ByteArray(12).also { java.security.SecureRandom().nextBytes(it) }
        cipher.init(
            javax.crypto.Cipher.ENCRYPT_MODE,
            sessionKey,
            javax.crypto.spec.GCMParameterSpec(128, iv)
        )
        val ciphertext = cipher.doFinal(message.toByteArray(Charsets.UTF_8))
        return iv + ciphertext
    }

    fun decryptMessage(data: ByteArray, sessionKey: SecretKeySpec): String {
        val iv = data.copyOfRange(0, 12)
        val ciphertext = data.copyOfRange(12, data.size)
        val cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(
            javax.crypto.Cipher.DECRYPT_MODE,
            sessionKey,
            javax.crypto.spec.GCMParameterSpec(128, iv)
        )
        return cipher.doFinal(ciphertext).toString(Charsets.UTF_8)
    }

    fun publicKeyToBytes(pub: PublicKey): ByteArray = pub.encoded
    fun privateKeyToBytes(priv: PrivateKey): ByteArray = priv.encoded
}
