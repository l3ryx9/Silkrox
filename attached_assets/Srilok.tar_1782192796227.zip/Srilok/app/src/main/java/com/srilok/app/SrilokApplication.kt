package com.srilok.app

import android.app.Application
import android.content.Context
import com.srilok.app.security.EmulatorDetector
import com.srilok.app.security.IntegrityChecker
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class SrilokApplication : Application() {

    @Inject lateinit var emulatorDetector: EmulatorDetector
    @Inject lateinit var integrityChecker: IntegrityChecker

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
    }

    override fun onCreate() {
        super.onCreate()
        runSecurityChecks()
    }

    private fun runSecurityChecks() {
        if (emulatorDetector.isEmulator()) {
            android.os.Process.killProcess(android.os.Process.myPid())
        }
        if (!integrityChecker.isAppIntegrityValid(this)) {
            android.os.Process.killProcess(android.os.Process.myPid())
        }
    }
}
