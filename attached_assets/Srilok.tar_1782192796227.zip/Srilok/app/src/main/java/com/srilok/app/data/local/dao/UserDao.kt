package com.srilok.app.data.local.dao

import androidx.room.*
import com.srilok.app.data.local.entities.UserEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE id = :id") fun getUser(id: String): Flow<UserEntity?>
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1") suspend fun getUserByUsername(username: String): UserEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertUser(user: UserEntity)
    @Update suspend fun updateUser(user: UserEntity)
    @Query("DELETE FROM users") suspend fun clearAll()
}
