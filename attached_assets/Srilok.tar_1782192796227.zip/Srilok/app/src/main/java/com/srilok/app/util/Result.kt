package com.srilok.app.util

sealed class Result<out T> {
    data class Success<T>(val data: T) : Result<T>()
    data class Error(val code: Int, val message: String) : Result<Nothing>()
    data class Exception(val throwable: kotlin.Exception) : Result<Nothing>()

    val isSuccess get() = this is Success
    val isError get() = this is Error || this is Exception

    fun getOrNull(): T? = if (this is Success) data else null
    fun errorMessage(): String = when (this) {
        is Error -> "[$code] $message"
        is Exception -> throwable.message ?: "Unknown error"
        else -> ""
    }
}
