package com.srilok.app.presentation.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.srilok.app.presentation.navigation.Screen
import com.srilok.app.presentation.ui.screens.home.SrilokBottomBar
import com.srilok.app.presentation.ui.theme.*
import com.srilok.app.presentation.viewmodel.AuthViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(navController: NavController, authVm: AuthViewModel = hiltViewModel()) {
    Scaffold(
        containerColor = SrilokBlack,
        topBar = {
            TopAppBar(
                title = { Text("Profil", color = SrilokOnSurface) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SrilokSurface),
                actions = {
                    IconButton(onClick = { navController.navigate(Screen.Settings.route) }) {
                        Icon(Icons.Default.Settings, null, tint = SrilokGold)
                    }
                }
            )
        },
        bottomBar = { SrilokBottomBar(navController) }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        Modifier.size(90.dp).clip(CircleShape).background(SrilokGoldDark),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Person, null, tint = SrilokGold, modifier = Modifier.size(48.dp))
                    }
                    Text("Utilisateur", style = MaterialTheme.typography.headlineSmall, color = SrilokOnSurface, fontWeight = FontWeight.Bold)
                    Surface(shape = RoundedCornerShape(20.dp), color = SrilokGoldDark.copy(0.3f)) {
                        Text("Acheteur", color = SrilokGold, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp), style = MaterialTheme.typography.labelMedium)
                    }
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = SrilokSurface), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(4.dp)) {
                    ProfileMenuItem(Icons.Default.ShoppingBag, "Mes commandes") { navController.navigate(Screen.Catalog.route) }
                    Divider(color = SrilokSurface3, modifier = Modifier.padding(horizontal = 16.dp))
                    ProfileMenuItem(Icons.Default.AccountBalanceWallet, "Mon portefeuille") { navController.navigate(Screen.Wallet.route) }
                    Divider(color = SrilokSurface3, modifier = Modifier.padding(horizontal = 16.dp))
                    ProfileMenuItem(Icons.Default.Message, "Messagerie") { navController.navigate(Screen.MessagingList.route) }
                    Divider(color = SrilokSurface3, modifier = Modifier.padding(horizontal = 16.dp))
                    ProfileMenuItem(Icons.Default.AdminPanelSettings, "Administration") { navController.navigate(Screen.AdminDashboard.route) }
                }
            }

            Spacer(Modifier.weight(1f))

            Button(
                onClick = { authVm.logout(); navController.navigate(Screen.Login.route) { popUpTo(0) } },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SrilokError, contentColor = SrilokOnSurface)
            ) {
                Icon(Icons.Default.Logout, null, Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Déconnexion", style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

@Composable
fun ProfileMenuItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Surface(modifier = Modifier.fillMaxWidth(), color = SrilokSurface, onClick = onClick) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = SrilokGold, modifier = Modifier.size(22.dp))
                Text(label, style = MaterialTheme.typography.bodyMedium, color = SrilokOnSurface)
            }
            Icon(Icons.Default.ChevronRight, null, tint = SrilokOnSurfaceMuted, modifier = Modifier.size(20.dp))
        }
    }
}
