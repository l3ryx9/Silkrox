package com.srilok.app.data.local.dao

import androidx.room.*
import com.srilok.app.data.local.entities.ConversationEntity
import com.srilok.app.data.local.entities.MessageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE conversationId = :convId ORDER BY timestamp ASC")
    fun getMessages(convId: String): Flow<List<MessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertMessage(msg: MessageEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertMessages(msgs: List<MessageEntity>)

    @Query("UPDATE messages SET isRead = 1 WHERE conversationId = :convId AND senderId != :myId")
    suspend fun markAsRead(convId: String, myId: String)

    @Query("DELETE FROM messages WHERE conversationId = :convId") suspend fun deleteConversation(convId: String)
}

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations ORDER BY lastMessageTimestamp DESC")
    fun getAllConversations(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE id = :id LIMIT 1")
    suspend fun getConversation(id: String): ConversationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(conv: ConversationEntity)
    @Query("DELETE FROM conversations WHERE id = :id") suspend fun delete(id: String)
}
