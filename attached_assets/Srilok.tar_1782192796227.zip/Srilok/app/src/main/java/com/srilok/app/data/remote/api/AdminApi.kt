package com.srilok.app.data.remote.api

import com.srilok.app.data.remote.dto.*
import com.srilok.app.domain.model.AdminStats
import com.srilok.app.domain.model.Announcement
import retrofit2.Response
import retrofit2.http.*

interface AdminApi {
    @GET("admin/stats") suspend fun getStats(): Response<AdminStats>
    @GET("admin/users") suspend fun getUsers(@Query("page") page: Int = 1): Response<Map<String, Any>>
    @DELETE("admin/users/{id}") suspend fun deleteUser(@Path("id") id: String): Response<Unit>
    @POST("admin/users/{id}/ban") suspend fun banUser(@Path("id") id: String): Response<Unit>
    @GET("admin/announcements") suspend fun getAnnouncements(): Response<List<Announcement>>
    @POST("admin/announcements") suspend fun createAnnouncement(@Body body: Map<String, String>): Response<Announcement>
    @DELETE("admin/announcements/{id}") suspend fun deleteAnnouncement(@Path("id") id: String): Response<Unit>
    @GET("admin/logs") suspend fun getAuditLogs(@Query("page") page: Int = 1): Response<Map<String, Any>>
}
