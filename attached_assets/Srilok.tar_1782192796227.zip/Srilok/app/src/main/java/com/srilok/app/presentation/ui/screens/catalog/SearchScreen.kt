package com.srilok.app.presentation.ui.screens.catalog

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.srilok.app.presentation.navigation.Screen
import com.srilok.app.presentation.ui.screens.home.ProductCard
import com.srilok.app.presentation.ui.theme.*
import com.srilok.app.presentation.viewmodel.ProductViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(navController: NavController, vm: ProductViewModel = hiltViewModel()) {
    val query by vm.searchQuery.collectAsState()
    val results by vm.searchResults.collectAsState()

    Scaffold(
        containerColor = SrilokBlack,
        topBar = {
            TopAppBar(
                title = {
                    TextField(
                        value = query,
                        onValueChange = vm::onSearchQuery,
                        placeholder = { Text("Rechercher...", color = SrilokOnSurfaceMuted) },
                        singleLine = true,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = SrilokSurface2,
                            unfocusedContainerColor = SrilokSurface2,
                            focusedTextColor = SrilokOnSurface,
                            unfocusedTextColor = SrilokOnSurface,
                            cursorColor = SrilokGold,
                            focusedIndicatorColor = SrilokGold,
                            unfocusedIndicatorColor = SrilokSurface3
                        ),
                        leadingIcon = { Icon(Icons.Default.Search, null, tint = SrilokGold) },
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, null, tint = SrilokGold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SrilokSurface)
            )
        }
    ) { padding ->
        if (query.isBlank()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Search, null, tint = SrilokGoldDark, modifier = Modifier.size(64.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Tapez pour rechercher", color = SrilokOnSurfaceMuted, style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize().padding(padding)
            ) {
                items(results) { product ->
                    ProductCard(product = product, onClick = { navController.navigate(Screen.ProductDetail.createRoute(product.id)) })
                }
            }
        }
    }
}
