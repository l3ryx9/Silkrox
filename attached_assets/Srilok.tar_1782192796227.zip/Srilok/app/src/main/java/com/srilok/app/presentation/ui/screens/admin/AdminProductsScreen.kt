package com.srilok.app.presentation.ui.screens.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.srilok.app.domain.model.Product
import com.srilok.app.presentation.ui.theme.*
import com.srilok.app.presentation.viewmodel.ProductViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminProductsScreen(navController: NavController, vm: ProductViewModel = hiltViewModel()) {
    val products by vm.products.collectAsState()
    var showCreateDialog by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = SrilokBlack,
        topBar = {
            TopAppBar(
                title = { Text("Annonces (${products.size})", color = SrilokOnSurface) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SrilokSurface),
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Icon(Icons.Default.ArrowBack, null, tint = SrilokGold) } }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showCreateDialog = true }, containerColor = SrilokGold, contentColor = SrilokBlack) {
                Icon(Icons.Default.Add, null)
            }
        }
    ) { padding ->
        if (products.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Storefront, null, tint = SrilokGoldDark, modifier = Modifier.size(56.dp))
                    Text("Aucune annonce", color = SrilokOnSurfaceMuted, style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(products.size) { i -> AdminProductItem(product = products[i]) }
            }
        }
    }
}

@Composable
fun AdminProductItem(product: Product) {
    Card(colors = CardDefaults.cardColors(containerColor = SrilokSurface), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(product.title, style = MaterialTheme.typography.labelLarge, color = SrilokOnSurface, maxLines = 1)
                Text("%.8f BTC".format(product.price), style = MaterialTheme.typography.labelMedium, color = SrilokGold)
                Text("Stock: ${product.quantity} • ${product.status}", style = MaterialTheme.typography.labelSmall, color = SrilokOnSurfaceMuted)
            }
            Row {
                IconButton(onClick = {}) { Icon(Icons.Default.Edit, null, tint = SrilokGold, modifier = Modifier.size(18.dp)) }
                IconButton(onClick = {}) { Icon(Icons.Default.MoreVert, null, tint = SrilokOnSurfaceMuted, modifier = Modifier.size(18.dp)) }
            }
        }
    }
}
