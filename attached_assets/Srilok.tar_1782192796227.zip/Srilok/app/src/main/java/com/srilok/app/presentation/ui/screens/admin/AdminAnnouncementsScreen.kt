package com.srilok.app.presentation.ui.screens.admin

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.srilok.app.presentation.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminAnnouncementsScreen(navController: NavController) {
    var showDialog by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }

    Scaffold(
        containerColor = SrilokBlack,
        topBar = {
            TopAppBar(
                title = { Text("Annonces système", color = SrilokOnSurface) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SrilokSurface),
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Icon(Icons.Default.ArrowBack, null, tint = SrilokGold) } }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showDialog = true }, containerColor = SrilokGold, contentColor = SrilokBlack) {
                Icon(Icons.Default.Add, null)
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Campaign, null, tint = SrilokGoldDark, modifier = Modifier.size(56.dp))
                Text("Aucune annonce publiée", color = SrilokOnSurfaceMuted, style = MaterialTheme.typography.bodyMedium)
            }
        }

        if (showDialog) {
            AlertDialog(
                onDismissRequest = { showDialog = false },
                containerColor = SrilokSurface,
                title = { Text("Nouvelle annonce", color = SrilokGold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = title, onValueChange = { title = it },
                            label = { Text("Titre") }, singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SrilokGold, unfocusedBorderColor = SrilokSurface3,
                                focusedTextColor = SrilokOnSurface, unfocusedTextColor = SrilokOnSurface,
                                cursorColor = SrilokGold, focusedContainerColor = SrilokSurface, unfocusedContainerColor = SrilokSurface,
                                focusedLabelColor = SrilokGold, unfocusedLabelColor = SrilokOnSurfaceMuted
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = content, onValueChange = { content = it },
                            label = { Text("Contenu") }, minLines = 3,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SrilokGold, unfocusedBorderColor = SrilokSurface3,
                                focusedTextColor = SrilokOnSurface, unfocusedTextColor = SrilokOnSurface,
                                cursorColor = SrilokGold, focusedContainerColor = SrilokSurface, unfocusedContainerColor = SrilokSurface,
                                focusedLabelColor = SrilokGold, unfocusedLabelColor = SrilokOnSurfaceMuted
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(onClick = { showDialog = false; title = ""; content = "" },
                        colors = ButtonDefaults.buttonColors(containerColor = SrilokGold, contentColor = SrilokBlack)) {
                        Text("Publier")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDialog = false }) { Text("Annuler", color = SrilokOnSurfaceMuted) }
                }
            )
        }
    }
}
