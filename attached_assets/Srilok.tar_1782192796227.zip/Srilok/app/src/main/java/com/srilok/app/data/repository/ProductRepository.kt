package com.srilok.app.data.repository

import com.srilok.app.data.local.dao.ProductDao
import com.srilok.app.data.local.entities.ProductEntity
import com.srilok.app.data.remote.api.ProductApi
import com.srilok.app.data.remote.dto.CreateProductRequest
import com.srilok.app.data.remote.dto.UpdateProductRequest
import com.srilok.app.domain.model.Product
import com.srilok.app.domain.model.ProductStatus
import com.srilok.app.util.Result
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.time.Instant
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ProductRepository @Inject constructor(
    private val productApi: ProductApi,
    private val productDao: ProductDao,
    private val gson: Gson
) {
    fun getProducts(): Flow<List<Product>> = productDao.getAllProducts().map { list -> list.map { it.toDomain(gson) } }
    fun getProduct(id: String): Flow<Product?> = productDao.getProduct(id).map { it?.toDomain(gson) }
    fun getFeatured(): Flow<List<Product>> = productDao.getFeatured().map { list -> list.map { it.toDomain(gson) } }
    fun getPopular(): Flow<List<Product>> = productDao.getPopular().map { list -> list.map { it.toDomain(gson) } }
    fun search(query: String): Flow<List<Product>> = productDao.search(query).map { list -> list.map { it.toDomain(gson) } }
    fun getByCategory(categoryId: String): Flow<List<Product>> = productDao.getByCategory(categoryId).map { list -> list.map { it.toDomain(gson) } }

    suspend fun syncProducts(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val response = productApi.getProducts()
            if (response.isSuccessful) {
                val entities = response.body()!!.products.map { dto ->
                    ProductEntity(dto.id, dto.title, dto.description, dto.price, dto.categoryId, dto.sellerId,
                        gson.toJson(dto.images), dto.quantity, dto.status, dto.viewCount, dto.orderCount, dto.featured, dto.createdAt, dto.updatedAt)
                }
                productDao.insertAll(entities)
                Result.Success(Unit)
            } else Result.Error(response.code(), response.message())
        } catch (e: Exception) { Result.Exception(e) }
    }

    suspend fun createProduct(title: String, description: String, price: Double, categoryId: String, quantity: Int, images: List<String>): Result<Product> =
        withContext(Dispatchers.IO) {
            try {
                val response = productApi.createProduct(CreateProductRequest(title, description, price, categoryId, quantity, images))
                if (response.isSuccessful) {
                    val dto = response.body()!!
                    val entity = ProductEntity(dto.id, dto.title, dto.description, dto.price, dto.categoryId, dto.sellerId,
                        gson.toJson(dto.images), dto.quantity, dto.status, dto.viewCount, dto.orderCount, dto.featured, dto.createdAt, dto.updatedAt)
                    productDao.insert(entity)
                    Result.Success(entity.toDomain(gson))
                } else Result.Error(response.code(), response.message())
            } catch (e: Exception) { Result.Exception(e) }
        }

    suspend fun updateProduct(id: String, req: UpdateProductRequest): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val response = productApi.updateProduct(id, req)
            if (response.isSuccessful) Result.Success(Unit) else Result.Error(response.code(), response.message())
        } catch (e: Exception) { Result.Exception(e) }
    }

    suspend fun deleteProduct(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val response = productApi.deleteProduct(id)
            if (response.isSuccessful) { productDao.delete(id); Result.Success(Unit) } else Result.Error(response.code(), response.message())
        } catch (e: Exception) { Result.Exception(e) }
    }

    private fun ProductEntity.toDomain(gson: Gson) = Product(
        id, title, description, price, "BTC", categoryId, sellerId,
        gson.fromJson(imagesJson, Array<String>::class.java).toList(),
        quantity, ProductStatus.valueOf(status), viewCount, orderCount, featured,
        Instant.ofEpochMilli(createdAt), Instant.ofEpochMilli(updatedAt)
    )
}
