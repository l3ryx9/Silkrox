package com.srilok.app.presentation.ui.screens.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.srilok.app.presentation.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminOrdersScreen(navController: NavController) {
    var selectedStatus by remember { mutableStateOf("Tous") }
    val statuses = listOf("Tous", "En attente", "Confirmé", "Terminé", "Annulé")

    Scaffold(
        containerColor = SrilokBlack,
        topBar = {
            TopAppBar(
                title = { Text("Commandes", color = SrilokOnSurface) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SrilokSurface),
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Icon(Icons.Default.ArrowBack, null, tint = SrilokGold) } }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            ScrollableTabRow(
                selectedTabIndex = statuses.indexOf(selectedStatus),
                containerColor = SrilokSurface,
                contentColor = SrilokGold,
                edgePadding = 8.dp
            ) {
                statuses.forEachIndexed { i, s ->
                    Tab(selected = selectedStatus == s, onClick = { selectedStatus = s },
                        text = { Text(s, style = MaterialTheme.typography.labelMedium) })
                }
            }
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.ShoppingBag, null, tint = SrilokGoldDark, modifier = Modifier.size(56.dp))
                    Text("Aucune commande", color = SrilokOnSurfaceMuted, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
