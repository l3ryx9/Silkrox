package com.srilok.app.presentation.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.srilok.app.presentation.ui.screens.auth.LoginScreen
import com.srilok.app.presentation.ui.screens.auth.RegisterScreen
import com.srilok.app.presentation.ui.screens.catalog.CatalogScreen
import com.srilok.app.presentation.ui.screens.catalog.ProductDetailScreen
import com.srilok.app.presentation.ui.screens.catalog.SearchScreen
import com.srilok.app.presentation.ui.screens.cart.CartScreen
import com.srilok.app.presentation.ui.screens.wallet.WalletScreen
import com.srilok.app.presentation.ui.screens.wallet.PaymentScreen
import com.srilok.app.presentation.ui.screens.messaging.MessagingListScreen
import com.srilok.app.presentation.ui.screens.messaging.ConversationScreen
import com.srilok.app.presentation.ui.screens.home.HomeScreen
import com.srilok.app.presentation.ui.screens.profile.ProfileScreen
import com.srilok.app.presentation.ui.screens.settings.SettingsScreen
import com.srilok.app.presentation.ui.screens.admin.AdminDashboardScreen
import com.srilok.app.presentation.ui.screens.admin.AdminOrdersScreen
import com.srilok.app.presentation.ui.screens.admin.AdminUsersScreen
import com.srilok.app.presentation.ui.screens.admin.AdminProductsScreen
import com.srilok.app.presentation.ui.screens.admin.AdminAnnouncementsScreen

sealed class Screen(val route: String) {
    object Login : Screen("login")
    object Register : Screen("register")
    object Home : Screen("home")
    object Catalog : Screen("catalog")
    object Search : Screen("search")
    object ProductDetail : Screen("product/{productId}") {
        fun createRoute(id: String) = "product/$id"
    }
    object Cart : Screen("cart")
    object Wallet : Screen("wallet")
    object Payment : Screen("payment/{orderId}") {
        fun createRoute(id: String) = "payment/$id"
    }
    object MessagingList : Screen("messaging")
    object Conversation : Screen("conversation/{convId}") {
        fun createRoute(id: String) = "conversation/$id"
    }
    object Profile : Screen("profile")
    object Settings : Screen("settings")
    object AdminDashboard : Screen("admin/dashboard")
    object AdminOrders : Screen("admin/orders")
    object AdminUsers : Screen("admin/users")
    object AdminProducts : Screen("admin/products")
    object AdminAnnouncements : Screen("admin/announcements")
}

@Composable
fun SrilokNavGraph(navController: NavHostController, startDestination: String) {
    NavHost(navController = navController, startDestination = startDestination) {
        composable(Screen.Login.route) { LoginScreen(navController) }
        composable(Screen.Register.route) { RegisterScreen(navController) }
        composable(Screen.Home.route) { HomeScreen(navController) }
        composable(Screen.Catalog.route) { CatalogScreen(navController) }
        composable(Screen.Search.route) { SearchScreen(navController) }
        composable(Screen.ProductDetail.route, arguments = listOf(navArgument("productId") { type = NavType.StringType })) {
            ProductDetailScreen(navController, it.arguments?.getString("productId") ?: "")
        }
        composable(Screen.Cart.route) { CartScreen(navController) }
        composable(Screen.Wallet.route) { WalletScreen(navController) }
        composable(Screen.Payment.route, arguments = listOf(navArgument("orderId") { type = NavType.StringType })) {
            PaymentScreen(navController, it.arguments?.getString("orderId") ?: "")
        }
        composable(Screen.MessagingList.route) { MessagingListScreen(navController) }
        composable(Screen.Conversation.route, arguments = listOf(navArgument("convId") { type = NavType.StringType })) {
            ConversationScreen(navController, it.arguments?.getString("convId") ?: "")
        }
        composable(Screen.Profile.route) { ProfileScreen(navController) }
        composable(Screen.Settings.route) { SettingsScreen(navController) }
        composable(Screen.AdminDashboard.route) { AdminDashboardScreen(navController) }
        composable(Screen.AdminOrders.route) { AdminOrdersScreen(navController) }
        composable(Screen.AdminUsers.route) { AdminUsersScreen(navController) }
        composable(Screen.AdminProducts.route) { AdminProductsScreen(navController) }
        composable(Screen.AdminAnnouncements.route) { AdminAnnouncementsScreen(navController) }
    }
}
