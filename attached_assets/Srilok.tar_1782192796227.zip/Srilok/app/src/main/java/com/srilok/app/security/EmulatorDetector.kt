package com.srilok.app.security

import android.content.Context
import android.os.Build
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class EmulatorDetector @Inject constructor() {

    fun isEmulator(): Boolean {
        var score = 0
        if (Build.FINGERPRINT.startsWith("generic")) score++
        if (Build.FINGERPRINT.startsWith("unknown")) score++
        if (Build.MODEL.contains("google_sdk")) score++
        if (Build.MODEL.contains("Emulator")) score++
        if (Build.MODEL.contains("Android SDK built for x86")) score++
        if (Build.MANUFACTURER.contains("Genymotion")) score++
        if (Build.BRAND.startsWith("generic") && Build.DEVICE.startsWith("generic")) score++
        if (Build.PRODUCT == "google_sdk") score++
        if (Build.HARDWARE == "goldfish") score++
        if (Build.HARDWARE == "ranchu") score++
        if (Build.TAGS?.contains("test-keys") == true) score++

        val qemuFiles = listOf(
            "/dev/socket/qemud",
            "/dev/qemu_pipe",
            "/system/lib/libc_malloc_debug_qemu.so",
            "/sys/qemu_trace",
            "/system/bin/qemu-props"
        )
        if (qemuFiles.any { File(it).exists() }) score += 2

        val pipesFiles = listOf("/dev/socket/genyd", "/dev/socket/baseband_genyd")
        if (pipesFiles.any { File(it).exists() }) score += 2

        return score >= 3
    }
}
