package com.srilok.app.data.remote.api

import com.srilok.app.data.remote.dto.*
import retrofit2.Response
import retrofit2.http.*

interface OrderApi {
    @GET("orders") suspend fun getOrders(): Response<List<OrderDto>>
    @GET("orders/{id}") suspend fun getOrder(@Path("id") id: String): Response<OrderDto>
    @POST("orders") suspend fun createOrder(@Body request: CreateOrderRequest): Response<OrderDto>
    @PATCH("orders/{id}/cancel") suspend fun cancelOrder(@Path("id") id: String): Response<OrderDto>
    @GET("admin/orders") suspend fun getAdminOrders(@Query("status") status: String? = null): Response<AdminOrderListResponse>
    @PATCH("admin/orders/{id}/status") suspend fun updateOrderStatus(@Path("id") id: String, @Body body: Map<String, String>): Response<OrderDto>
}
