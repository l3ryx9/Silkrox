package com.srilok.app.data.local.dao

import androidx.room.*
import com.srilok.app.data.local.entities.OrderEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders WHERE buyerId = :userId ORDER BY createdAt DESC")
    fun getOrdersForBuyer(userId: String): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE sellerId = :userId ORDER BY createdAt DESC")
    fun getOrdersForSeller(userId: String): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE id = :id LIMIT 1")
    suspend fun getOrder(id: String): OrderEntity?

    @Query("SELECT * FROM orders ORDER BY createdAt DESC")
    fun getAllOrders(): Flow<List<OrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(order: OrderEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(orders: List<OrderEntity>)
    @Update suspend fun update(order: OrderEntity)
    @Query("DELETE FROM orders WHERE id = :id") suspend fun delete(id: String)
}
