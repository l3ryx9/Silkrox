package com.srilok.app.data.remote.dto

import com.google.gson.annotations.SerializedName

data class RegisterRequest(
    @SerializedName("username") val username: String,
    @SerializedName("password") val password: String,
    @SerializedName("captcha_token") val captchaToken: String,
    @SerializedName("public_key") val publicKey: String
)

data class LoginRequest(
    @SerializedName("username") val username: String,
    @SerializedName("password") val password: String,
    @SerializedName("device_fingerprint") val deviceFingerprint: String
)

data class AuthResponse(
    @SerializedName("user_id") val userId: String,
    @SerializedName("access_token") val accessToken: String,
    @SerializedName("refresh_token") val refreshToken: String,
    @SerializedName("expires_in") val expiresIn: Long,
    @SerializedName("wallet_address") val walletAddress: String,
    @SerializedName("role") val role: String
)

data class RefreshTokenRequest(
    @SerializedName("refresh_token") val refreshToken: String
)

data class PasswordStrengthResponse(
    @SerializedName("score") val score: Int,
    @SerializedName("feedback") val feedback: List<String>
)
