package com.srilok.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.srilok.app.data.repository.ProductRepository
import com.srilok.app.domain.model.Product
import com.srilok.app.util.Result
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProductViewModel @Inject constructor(private val repo: ProductRepository) : ViewModel() {

    val products: StateFlow<List<Product>> = repo.getProducts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val featured: StateFlow<List<Product>> = repo.getFeatured()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val popular: StateFlow<List<Product>> = repo.getPopular()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedProduct = MutableStateFlow<Product?>(null)
    val selectedProduct: StateFlow<Product?> = _selectedProduct.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val searchResults: StateFlow<List<Product>> = _searchQuery
        .debounce(300)
        .flatMapLatest { q -> if (q.isBlank()) flowOf(emptyList()) else repo.search(q) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    init { sync() }

    fun sync() = viewModelScope.launch {
        _isLoading.value = true
        val result = repo.syncProducts()
        if (result is Result.Exception) _error.value = result.errorMessage()
        _isLoading.value = false
    }

    fun selectProduct(id: String) = viewModelScope.launch {
        repo.getProduct(id).collect { _selectedProduct.value = it }
    }

    fun onSearchQuery(q: String) { _searchQuery.value = q }

    fun getByCategory(categoryId: String): Flow<List<Product>> = repo.getByCategory(categoryId)
}
