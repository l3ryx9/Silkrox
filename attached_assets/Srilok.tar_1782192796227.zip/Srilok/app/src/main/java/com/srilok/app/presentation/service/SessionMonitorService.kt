package com.srilok.app.presentation.service

import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.srilok.app.util.SessionManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import javax.inject.Inject

@AndroidEntryPoint
class SessionMonitorService : Service() {

    @Inject lateinit var sessionManager: SessionManager
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        scope.launch {
            while (isActive) {
                if (!sessionManager.isSessionValid()) {
                    sessionManager.clearSession()
                    stopSelf()
                }
                delay(60_000)
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}
