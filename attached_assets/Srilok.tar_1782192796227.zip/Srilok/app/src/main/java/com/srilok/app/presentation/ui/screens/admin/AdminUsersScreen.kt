package com.srilok.app.presentation.ui.screens.admin

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.srilok.app.presentation.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminUsersScreen(navController: NavController) {
    var searchQuery by remember { mutableStateOf("") }
    Scaffold(
        containerColor = SrilokBlack,
        topBar = {
            TopAppBar(
                title = { Text("Utilisateurs", color = SrilokOnSurface) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SrilokSurface),
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Icon(Icons.Default.ArrowBack, null, tint = SrilokGold) } }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = searchQuery, onValueChange = { searchQuery = it },
                placeholder = { Text("Rechercher un utilisateur", color = SrilokOnSurfaceMuted) },
                leadingIcon = { Icon(Icons.Default.Search, null, tint = SrilokGold) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = SrilokGold, unfocusedBorderColor = SrilokSurface3,
                    focusedTextColor = SrilokOnSurface, unfocusedTextColor = SrilokOnSurface,
                    cursorColor = SrilokGold, focusedContainerColor = SrilokSurface, unfocusedContainerColor = SrilokSurface
                ),
                modifier = Modifier.fillMaxWidth(), singleLine = true
            )
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.People, null, tint = SrilokGoldDark, modifier = Modifier.size(56.dp))
                    Text("Aucun utilisateur", color = SrilokOnSurfaceMuted, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
