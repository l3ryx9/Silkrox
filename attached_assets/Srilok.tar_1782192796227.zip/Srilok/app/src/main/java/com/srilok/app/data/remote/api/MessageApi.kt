package com.srilok.app.data.remote.api

import com.srilok.app.data.remote.dto.*
import retrofit2.Response
import retrofit2.http.*

interface MessageApi {
    @GET("conversations") suspend fun getConversations(): Response<List<ConversationDto>>
    @GET("conversations/{id}/messages") suspend fun getMessages(@Path("id") convId: String): Response<List<MessageDto>>
    @POST("messages") suspend fun sendMessage(@Body request: SendMessageRequest): Response<MessageDto>
    @POST("keys/exchange") suspend fun exchangeKeys(@Body request: KeyExchangeRequest): Response<KeyExchangeResponse>
    @GET("users/{id}/public-key") suspend fun getPublicKey(@Path("id") userId: String): Response<Map<String, String>>
    @PUT("messages/{id}/read") suspend fun markRead(@Path("id") msgId: String): Response<Unit>
}
