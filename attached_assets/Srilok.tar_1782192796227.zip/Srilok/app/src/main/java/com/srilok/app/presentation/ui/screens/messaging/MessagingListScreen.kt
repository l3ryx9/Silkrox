package com.srilok.app.presentation.ui.screens.messaging

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.srilok.app.presentation.navigation.Screen
import com.srilok.app.presentation.ui.theme.*
import com.srilok.app.presentation.viewmodel.MessageViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessagingListScreen(navController: NavController, vm: MessageViewModel = hiltViewModel()) {
    Scaffold(
        containerColor = SrilokBlack,
        topBar = {
            TopAppBar(
                title = { Text("Messagerie privée", color = SrilokOnSurface) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SrilokSurface),
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, null, tint = SrilokGold)
                    }
                },
                actions = {
                    Surface(shape = RoundedCornerShape(6.dp), color = SrilokGoldDark.copy(0.3f)) {
                        Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.Lock, null, tint = SrilokGold, modifier = Modifier.size(12.dp))
                            Text("E2EE", style = MaterialTheme.typography.labelSmall, color = SrilokGold)
                        }
                    }
                    Spacer(Modifier.width(8.dp))
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { /* new conversation */ }, containerColor = SrilokGold, contentColor = SrilokBlack) {
                Icon(Icons.Default.Edit, null)
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Default.LockOpen, null, tint = SrilokGoldDark, modifier = Modifier.size(64.dp))
                Text("Messagerie chiffrée de bout en bout", color = SrilokOnSurfaceMuted, style = MaterialTheme.typography.bodyMedium)
                Text("Vos messages sont protégés par chiffrement AES-256-GCM", color = SrilokOnSurfaceMuted, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
