package com.srilok.app.data.repository

import com.srilok.app.data.local.dao.TransactionDao
import com.srilok.app.data.local.entities.TransactionEntity
import com.srilok.app.data.remote.api.WalletApi
import com.srilok.app.domain.model.Transaction
import com.srilok.app.domain.model.TransactionType
import com.srilok.app.domain.model.Wallet
import com.srilok.app.util.Result
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.time.Instant
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WalletRepository @Inject constructor(
    private val walletApi: WalletApi,
    private val transactionDao: TransactionDao
) {
    fun getTransactions(address: String): Flow<List<Transaction>> =
        transactionDao.getTransactions(address).map { list ->
            list.map { Transaction(it.txHash, it.walletAddress, it.amount, it.confirmations, TransactionType.valueOf(it.type), Instant.ofEpochMilli(it.timestamp)) }
        }

    suspend fun getWallet(): Result<Wallet> = withContext(Dispatchers.IO) {
        try {
            val response = walletApi.getWallet()
            if (response.isSuccessful) {
                val dto = response.body()!!
                val txResponse = walletApi.getTransactions()
                val txs = if (txResponse.isSuccessful) txResponse.body()!! else emptyList()
                val txEntities = txs.map { TransactionEntity(it.txHash, it.walletAddress, it.amount, it.confirmations, it.type, it.timestamp) }
                transactionDao.insertAll(txEntities)
                val domainTxs = txs.map { Transaction(it.txHash, it.walletAddress, it.amount, it.confirmations, TransactionType.valueOf(it.type), Instant.ofEpochMilli(it.timestamp)) }
                Result.Success(Wallet(dto.address, dto.balanceBtc, domainTxs))
            } else Result.Error(response.code(), response.message())
        } catch (e: Exception) { Result.Exception(e) }
    }

    suspend fun getPaymentStatus(orderId: String) = withContext(Dispatchers.IO) {
        try {
            val response = walletApi.getPaymentStatus(orderId)
            if (response.isSuccessful) Result.Success(response.body()!!) else Result.Error(response.code(), response.message())
        } catch (e: Exception) { Result.Exception(e) }
    }
}
