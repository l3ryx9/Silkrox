package com.srilok.app.data.remote.dto

import com.google.gson.annotations.SerializedName

data class OrderDto(
    @SerializedName("id") val id: String,
    @SerializedName("product_id") val productId: String,
    @SerializedName("buyer_id") val buyerId: String,
    @SerializedName("seller_id") val sellerId: String,
    @SerializedName("quantity") val quantity: Int,
    @SerializedName("total_btc") val totalBtc: Double,
    @SerializedName("payment_address") val paymentAddress: String,
    @SerializedName("status") val status: String,
    @SerializedName("tx_hash") val txHash: String?,
    @SerializedName("confirmations") val confirmations: Int,
    @SerializedName("created_at") val createdAt: Long,
    @SerializedName("updated_at") val updatedAt: Long
)

data class CreateOrderRequest(
    @SerializedName("product_id") val productId: String,
    @SerializedName("quantity") val quantity: Int
)

data class AdminOrderListResponse(
    @SerializedName("orders") val orders: List<OrderDto>,
    @SerializedName("total") val total: Int
)
