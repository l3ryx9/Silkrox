package com.srilok.app.presentation.ui.screens.cart

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.srilok.app.presentation.navigation.Screen
import com.srilok.app.presentation.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartScreen(navController: NavController) {
    Scaffold(
        containerColor = SrilokBlack,
        topBar = {
            TopAppBar(
                title = { Text("Panier", color = SrilokOnSurface) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SrilokSurface),
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Icon(Icons.Default.ArrowBack, null, tint = SrilokGold) } }
            )
        },
        bottomBar = {
            Surface(color = SrilokSurface, shadowElevation = 8.dp) {
                Column(Modifier.padding(16.dp).navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total", style = MaterialTheme.typography.titleMedium, color = SrilokOnSurface)
                        Text("0.00000000 BTC", style = MaterialTheme.typography.titleMedium, color = SrilokGold, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { navController.navigate(Screen.Wallet.route) },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SrilokGold, contentColor = SrilokBlack)
                    ) {
                        Icon(Icons.Default.AccountBalanceWallet, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Payer en Bitcoin", style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Default.ShoppingCart, null, tint = SrilokGoldDark, modifier = Modifier.size(72.dp))
                Text("Panier vide", style = MaterialTheme.typography.titleMedium, color = SrilokOnSurfaceMuted)
                TextButton(onClick = { navController.navigate(Screen.Catalog.route) }) {
                    Text("Voir le catalogue", color = SrilokGold)
                }
            }
        }
    }
}
