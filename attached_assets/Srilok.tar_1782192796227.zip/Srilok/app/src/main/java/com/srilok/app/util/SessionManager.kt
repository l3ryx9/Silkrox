package com.srilok.app.util

import android.content.Context
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SessionManager @Inject constructor(@ApplicationContext private val context: Context) {

    companion object {
        private const val PREFS_NAME = "srilok_session"
        private const val KEY_ACCESS_TOKEN = "at"
        private const val KEY_REFRESH_TOKEN = "rt"
        private const val KEY_EXPIRES_AT = "exp"
        private const val KEY_USER_ID = "uid"
        private const val KEY_PUBLIC_KEY = "pk"
        private const val KEY_ROLE = "role"
        private const val INACTIVITY_TIMEOUT_MS = 15 * 60 * 1000L
        private const val KEY_LAST_ACTIVE = "la"
    }

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context, PREFS_NAME, masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveTokens(accessToken: String, refreshToken: String, expiresIn: Long) {
        prefs.edit()
            .putString(KEY_ACCESS_TOKEN, accessToken)
            .putString(KEY_REFRESH_TOKEN, refreshToken)
            .putLong(KEY_EXPIRES_AT, System.currentTimeMillis() + expiresIn * 1000)
            .putLong(KEY_LAST_ACTIVE, System.currentTimeMillis())
            .apply()
    }

    fun getAccessToken(): String? = prefs.getString(KEY_ACCESS_TOKEN, null)
    fun getRefreshToken(): String? = prefs.getString(KEY_REFRESH_TOKEN, null)
    fun getUserId(): String? = prefs.getString(KEY_USER_ID, null)
    fun getPublicKey(): String? = prefs.getString(KEY_PUBLIC_KEY, null)
    fun getRole(): String? = prefs.getString(KEY_ROLE, null)

    fun saveUserInfo(userId: String, publicKey: String, role: String) {
        prefs.edit()
            .putString(KEY_USER_ID, userId)
            .putString(KEY_PUBLIC_KEY, publicKey)
            .putString(KEY_ROLE, role)
            .apply()
    }

    fun updateLastActive() {
        prefs.edit().putLong(KEY_LAST_ACTIVE, System.currentTimeMillis()).apply()
    }

    fun isSessionValid(): Boolean {
        val token = getAccessToken() ?: return false
        val expiresAt = prefs.getLong(KEY_EXPIRES_AT, 0L)
        val lastActive = prefs.getLong(KEY_LAST_ACTIVE, 0L)
        val now = System.currentTimeMillis()
        if (now > expiresAt) return false
        if (now - lastActive > INACTIVITY_TIMEOUT_MS) { clearSession(); return false }
        return token.isNotBlank()
    }

    fun clearSession() {
        prefs.edit().clear().apply()
    }
}
