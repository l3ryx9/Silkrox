package com.srilok.app.domain.model

import java.time.Instant

data class User(
    val id: String,
    val username: String,
    val role: UserRole,
    val walletAddress: String,
    val publicKey: String,
    val createdAt: Instant,
    val lastSeen: Instant
)

enum class UserRole { BUYER, SELLER, ADMIN }

data class Product(
    val id: String,
    val title: String,
    val description: String,
    val price: Double,
    val priceUnit: String = "BTC",
    val categoryId: String,
    val sellerId: String,
    val images: List<String>,
    val quantity: Int,
    val status: ProductStatus,
    val viewCount: Int = 0,
    val orderCount: Int = 0,
    val featured: Boolean = false,
    val createdAt: Instant,
    val updatedAt: Instant
)

enum class ProductStatus { ACTIVE, PENDING, DISABLED, SOLD_OUT }

data class Category(
    val id: String,
    val name: String,
    val iconUrl: String?
)

data class Order(
    val id: String,
    val productId: String,
    val buyerId: String,
    val sellerId: String,
    val quantity: Int,
    val totalBtc: Double,
    val paymentAddress: String,
    val status: OrderStatus,
    val txHash: String?,
    val confirmations: Int = 0,
    val createdAt: Instant,
    val updatedAt: Instant
)

enum class OrderStatus { PENDING_PAYMENT, PAYMENT_DETECTED, CONFIRMED, PROCESSING, COMPLETED, CANCELLED, REFUNDED }

data class Transaction(
    val txHash: String,
    val walletAddress: String,
    val amount: Double,
    val confirmations: Int,
    val type: TransactionType,
    val timestamp: Instant
)

enum class TransactionType { RECEIVED, SENT }

data class Message(
    val id: String,
    val conversationId: String,
    val senderId: String,
    val encryptedContent: ByteArray,
    val iv: ByteArray,
    val isRead: Boolean = false,
    val timestamp: Instant
) {
    override fun equals(other: Any?) = other is Message && id == other.id
    override fun hashCode() = id.hashCode()
}

data class Conversation(
    val id: String,
    val participantIds: List<String>,
    val lastMessageTimestamp: Instant?,
    val unreadCount: Int = 0
)

data class Wallet(
    val address: String,
    val balanceBtc: Double,
    val transactions: List<Transaction>
)

data class Announcement(
    val id: String,
    val title: String,
    val content: String,
    val adminId: String,
    val createdAt: Instant,
    val isPinned: Boolean = false
)

data class AdminStats(
    val totalUsers: Int,
    val totalProducts: Int,
    val activeProducts: Int,
    val totalOrders: Int,
    val pendingOrders: Int,
    val totalRevenueBtc: Double
)
