package com.srilok.app.data.remote.dto

import com.google.gson.annotations.SerializedName

data class ProductDto(
    @SerializedName("id") val id: String,
    @SerializedName("title") val title: String,
    @SerializedName("description") val description: String,
    @SerializedName("price") val price: Double,
    @SerializedName("category_id") val categoryId: String,
    @SerializedName("seller_id") val sellerId: String,
    @SerializedName("images") val images: List<String>,
    @SerializedName("quantity") val quantity: Int,
    @SerializedName("status") val status: String,
    @SerializedName("view_count") val viewCount: Int,
    @SerializedName("order_count") val orderCount: Int,
    @SerializedName("featured") val featured: Boolean,
    @SerializedName("created_at") val createdAt: Long,
    @SerializedName("updated_at") val updatedAt: Long
)

data class CategoryDto(
    @SerializedName("id") val id: String,
    @SerializedName("name") val name: String,
    @SerializedName("icon_url") val iconUrl: String?
)

data class CreateProductRequest(
    @SerializedName("title") val title: String,
    @SerializedName("description") val description: String,
    @SerializedName("price") val price: Double,
    @SerializedName("category_id") val categoryId: String,
    @SerializedName("quantity") val quantity: Int,
    @SerializedName("images") val images: List<String>
)

data class UpdateProductRequest(
    @SerializedName("title") val title: String? = null,
    @SerializedName("description") val description: String? = null,
    @SerializedName("price") val price: Double? = null,
    @SerializedName("quantity") val quantity: Int? = null,
    @SerializedName("status") val status: String? = null
)

data class ProductListResponse(
    @SerializedName("products") val products: List<ProductDto>,
    @SerializedName("total") val total: Int,
    @SerializedName("page") val page: Int,
    @SerializedName("per_page") val perPage: Int
)
