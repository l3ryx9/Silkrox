package com.srilok.app.security

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class IntegrityChecker @Inject constructor() {

    companion object {
        private const val EXPECTED_SIGNATURE_SHA256 = "REPLACE_WITH_YOUR_RELEASE_SIGNATURE_SHA256"
    }

    fun isAppIntegrityValid(context: Context): Boolean {
        return try {
            val signatureHash = getSignatureHash(context)
            signatureHash == EXPECTED_SIGNATURE_SHA256
        } catch (e: Exception) {
            false
        }
    }

    private fun getSignatureHash(context: Context): String {
        val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val info = context.packageManager.getPackageInfo(
                context.packageName,
                PackageManager.GET_SIGNING_CERTIFICATES
            )
            info.signingInfo?.apkContentsSigners ?: emptyArray()
        } else {
            @Suppress("DEPRECATION")
            val info = context.packageManager.getPackageInfo(
                context.packageName,
                PackageManager.GET_SIGNATURES
            )
            info.signatures ?: emptyArray()
        }

        if (signatures.isEmpty()) return ""
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(signatures[0].toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun isDebuggerAttached(): Boolean {
        return android.os.Debug.isDebuggerConnected()
    }
}
