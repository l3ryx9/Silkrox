package com.srilok.app.data.repository

import com.srilok.app.data.local.dao.UserDao
import com.srilok.app.data.local.entities.UserEntity
import com.srilok.app.data.remote.api.AuthApi
import com.srilok.app.data.remote.dto.LoginRequest
import com.srilok.app.data.remote.dto.RegisterRequest
import com.srilok.app.security.CryptoManager
import com.srilok.app.security.E2EEManager
import com.srilok.app.util.DeviceUtil
import com.srilok.app.util.Result
import com.srilok.app.util.SessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuthRepository @Inject constructor(
    private val authApi: AuthApi,
    private val userDao: UserDao,
    private val cryptoManager: CryptoManager,
    private val e2eeManager: E2EEManager,
    private val sessionManager: SessionManager,
    private val deviceUtil: DeviceUtil
) {
    suspend fun register(username: String, password: String, captchaToken: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val identityKeyPair = e2eeManager.generateIdentityKeyPair()
                val publicKeyBase64 = android.util.Base64.encodeToString(
                    e2eeManager.publicKeyToBytes(identityKeyPair.public), android.util.Base64.NO_WRAP
                )
                val response = authApi.register(RegisterRequest(username, password, captchaToken, publicKeyBase64))
                if (response.isSuccessful) {
                    val body = response.body()!!
                    sessionManager.saveTokens(body.accessToken, body.refreshToken, body.expiresIn)
                    val privKeyEncrypted = cryptoManager.encrypt(e2eeManager.privateKeyToBytes(identityKeyPair.private))
                    userDao.insertUser(
                        UserEntity(body.userId, username, body.role, body.walletAddress, privKeyEncrypted, System.currentTimeMillis(), System.currentTimeMillis())
                    )
                    Result.Success(Unit)
                } else Result.Error(response.code(), response.message())
            } catch (e: Exception) {
                Result.Exception(e)
            }
        }

    suspend fun login(username: String, password: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val response = authApi.login(LoginRequest(username, password, deviceUtil.getFingerprint()))
                if (response.isSuccessful) {
                    val body = response.body()!!
                    sessionManager.saveTokens(body.accessToken, body.refreshToken, body.expiresIn)
                    Result.Success(Unit)
                } else Result.Error(response.code(), response.message())
            } catch (e: Exception) {
                Result.Exception(e)
            }
        }

    suspend fun logout(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            authApi.logout()
            sessionManager.clearSession()
            userDao.clearAll()
            Result.Success(Unit)
        } catch (e: Exception) {
            sessionManager.clearSession()
            Result.Success(Unit)
        }
    }

    fun isLoggedIn(): Boolean = sessionManager.isSessionValid()
}
