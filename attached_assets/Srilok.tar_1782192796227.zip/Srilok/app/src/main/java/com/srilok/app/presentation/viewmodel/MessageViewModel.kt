package com.srilok.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.srilok.app.data.repository.MessageRepository
import com.srilok.app.domain.model.Message
import com.srilok.app.util.Result
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MessageViewModel @Inject constructor(private val repo: MessageRepository) : ViewModel() {

    private val _currentConvId = MutableStateFlow<String?>(null)

    val messages: StateFlow<List<Message>> = _currentConvId
        .filterNotNull()
        .flatMapLatest { repo.getMessages(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _draft = MutableStateFlow("")
    val draft: StateFlow<String> = _draft.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _keyExchangeResult = MutableStateFlow<String?>(null)
    val keyExchangeResult: StateFlow<String?> = _keyExchangeResult.asStateFlow()

    fun loadConversation(convId: String) {
        _currentConvId.value = convId
        viewModelScope.launch { repo.syncMessages(convId) }
    }

    fun onDraftChange(v: String) { _draft.value = v }

    fun sendMessage(recipientId: String) = viewModelScope.launch {
        val convId = _currentConvId.value ?: return@launch
        val text = _draft.value.trim()
        if (text.isBlank()) return@launch
        _isLoading.value = true
        when (val result = repo.sendMessage(convId, text, recipientId)) {
            is Result.Success -> _draft.value = ""
            else -> _error.value = result.errorMessage()
        }
        _isLoading.value = false
    }

    fun initiateKeyExchange(recipientId: String) = viewModelScope.launch {
        _isLoading.value = true
        when (val result = repo.initiateKeyExchange(recipientId)) {
            is Result.Success -> { _keyExchangeResult.value = result.data; _currentConvId.value = result.data }
            else -> _error.value = result.errorMessage()
        }
        _isLoading.value = false
    }
}
