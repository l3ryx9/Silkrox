package com.srilok.app.presentation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.rememberNavController
import com.srilok.app.presentation.navigation.Screen
import com.srilok.app.presentation.navigation.SrilokNavGraph
import com.srilok.app.presentation.ui.theme.SrilokTheme
import com.srilok.app.presentation.viewmodel.AuthViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SrilokTheme {
                val navController = rememberNavController()
                val authViewModel: AuthViewModel = hiltViewModel()
                val isLoggedIn by authViewModel.isLoggedIn.collectAsState()
                val startDestination = if (isLoggedIn) Screen.Home.route else Screen.Login.route
                SrilokNavGraph(navController = navController, startDestination = startDestination)
            }
        }
    }
}
