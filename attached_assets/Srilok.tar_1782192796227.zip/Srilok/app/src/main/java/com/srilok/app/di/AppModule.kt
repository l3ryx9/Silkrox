package com.srilok.app.di

import com.google.gson.Gson
import com.srilok.app.security.CryptoManager
import com.srilok.app.security.E2EEManager
import com.srilok.app.security.EmulatorDetector
import com.srilok.app.security.IntegrityChecker
import com.srilok.app.security.SrilokCertificatePinner
import com.srilok.app.util.DeviceUtil
import com.srilok.app.util.SessionManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides @Singleton fun provideGson(): Gson = Gson()
    @Provides @Singleton fun provideCryptoManager(): CryptoManager = CryptoManager()
    @Provides @Singleton fun provideE2EEManager(cm: CryptoManager): E2EEManager = E2EEManager(cm)
    @Provides @Singleton fun provideEmulatorDetector(): EmulatorDetector = EmulatorDetector()
    @Provides @Singleton fun provideIntegrityChecker(): IntegrityChecker = IntegrityChecker()
    @Provides @Singleton fun provideCertPinner(): SrilokCertificatePinner = SrilokCertificatePinner()
}
