package com.srilok.app.data.repository

import com.srilok.app.data.local.dao.OrderDao
import com.srilok.app.data.local.entities.OrderEntity
import com.srilok.app.data.remote.api.OrderApi
import com.srilok.app.data.remote.dto.CreateOrderRequest
import com.srilok.app.domain.model.Order
import com.srilok.app.domain.model.OrderStatus
import com.srilok.app.util.Result
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.time.Instant
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class OrderRepository @Inject constructor(
    private val orderApi: OrderApi,
    private val orderDao: OrderDao
) {
    fun getBuyerOrders(userId: String): Flow<List<Order>> =
        orderDao.getOrdersForBuyer(userId).map { it.map(::toDomain) }

    fun getSellerOrders(userId: String): Flow<List<Order>> =
        orderDao.getOrdersForSeller(userId).map { it.map(::toDomain) }

    fun getAllOrders(): Flow<List<Order>> =
        orderDao.getAllOrders().map { it.map(::toDomain) }

    suspend fun createOrder(productId: String, quantity: Int): Result<Order> =
        withContext(Dispatchers.IO) {
            try {
                val response = orderApi.createOrder(CreateOrderRequest(productId, quantity))
                if (response.isSuccessful) {
                    val dto = response.body()!!
                    val entity = OrderEntity(dto.id, dto.productId, dto.buyerId, dto.sellerId,
                        dto.quantity, dto.totalBtc, dto.paymentAddress, dto.status, dto.txHash,
                        dto.confirmations, dto.createdAt, dto.updatedAt)
                    orderDao.insert(entity)
                    Result.Success(toDomain(entity))
                } else Result.Error(response.code(), response.message())
            } catch (e: Exception) { Result.Exception(e) }
        }

    suspend fun syncOrders(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val response = orderApi.getOrders()
            if (response.isSuccessful) {
                val entities = response.body()!!.map { dto ->
                    OrderEntity(dto.id, dto.productId, dto.buyerId, dto.sellerId,
                        dto.quantity, dto.totalBtc, dto.paymentAddress, dto.status, dto.txHash,
                        dto.confirmations, dto.createdAt, dto.updatedAt)
                }
                orderDao.insertAll(entities)
                Result.Success(Unit)
            } else Result.Error(response.code(), response.message())
        } catch (e: Exception) { Result.Exception(e) }
    }

    suspend fun cancelOrder(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val response = orderApi.cancelOrder(id)
            if (response.isSuccessful) Result.Success(Unit) else Result.Error(response.code(), response.message())
        } catch (e: Exception) { Result.Exception(e) }
    }

    private fun toDomain(e: OrderEntity) = Order(
        e.id, e.productId, e.buyerId, e.sellerId, e.quantity, e.totalBtc,
        e.paymentAddress, OrderStatus.valueOf(e.status), e.txHash, e.confirmations,
        Instant.ofEpochMilli(e.createdAt), Instant.ofEpochMilli(e.updatedAt)
    )
}
