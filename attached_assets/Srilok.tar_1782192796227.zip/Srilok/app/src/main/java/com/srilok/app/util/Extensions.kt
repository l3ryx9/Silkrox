package com.srilok.app.util

import android.util.Base64

fun ByteArray.toBase64(): String = Base64.encodeToString(this, Base64.NO_WRAP)
fun String.fromBase64(): ByteArray = Base64.decode(this, Base64.NO_WRAP)

fun Double.formatBtc(): String = "%.8f BTC".format(this)

fun String.isValidUsername(): Boolean =
    length in 3..30 && matches(Regex("^[a-zA-Z0-9_.-]+$"))

fun String.isStrongPassword(): Boolean {
    if (length < 8) return false
    val hasUpper = any { it.isUpperCase() }
    val hasDigit = any { it.isDigit() }
    val hasSpecial = any { "!@#\$%^&*()_+-=[]{}|;':\",./<>?".contains(it) }
    return hasUpper && hasDigit && hasSpecial
}
