package com.srilok.app.presentation.ui.screens.catalog

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.srilok.app.presentation.navigation.Screen
import com.srilok.app.presentation.ui.theme.*
import com.srilok.app.presentation.viewmodel.ProductViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductDetailScreen(navController: NavController, productId: String, vm: ProductViewModel = hiltViewModel()) {
    LaunchedEffect(productId) { vm.selectProduct(productId) }
    val product by vm.selectedProduct.collectAsState()

    Scaffold(
        containerColor = SrilokBlack,
        topBar = {
            TopAppBar(
                title = { Text(product?.title ?: "", color = SrilokOnSurface, maxLines = 1) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SrilokSurface),
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, null, tint = SrilokGold)
                    }
                }
            )
        }
    ) { padding ->
        product?.let { p ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())
            ) {
                if (p.images.isNotEmpty()) {
                    LazyRow(Modifier.fillMaxWidth().height(260.dp)) {
                        items(p.images) { img ->
                            AsyncImage(
                                model = img, contentDescription = null,
                                modifier = Modifier.fillParentMaxWidth().fillMaxHeight().padding(end = 2.dp),
                                contentScale = ContentScale.Crop
                            )
                        }
                    }
                } else {
                    Box(Modifier.fillMaxWidth().height(260.dp).background(SrilokSurface2), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Image, null, tint = SrilokOnSurfaceMuted, modifier = Modifier.size(80.dp))
                    }
                }

                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                        Text(p.title, style = MaterialTheme.typography.headlineSmall, color = SrilokOnSurface, modifier = Modifier.weight(1f))
                        if (p.featured) Icon(Icons.Default.Star, null, tint = SrilokGold, modifier = Modifier.size(24.dp))
                    }
                    Text("%.8f BTC".format(p.price), style = MaterialTheme.typography.headlineMedium, color = SrilokGold, fontWeight = FontWeight.Bold)

                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        InfoChip(Icons.Default.Inventory, "Stock: ${p.quantity}")
                        InfoChip(Icons.Default.Visibility, "${p.viewCount} vues")
                        InfoChip(Icons.Default.ShoppingBag, "${p.orderCount} ventes")
                    }

                    Divider(color = SrilokSurface3)

                    Text("Description", style = MaterialTheme.typography.titleMedium, color = SrilokGold)
                    Text(p.description, style = MaterialTheme.typography.bodyMedium, color = SrilokOnSurface, lineHeight = MaterialTheme.typography.bodyMedium.lineHeight)

                    Spacer(Modifier.height(8.dp))

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(
                            onClick = { navController.navigate(Screen.MessagingList.route) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = SrilokGold),
                            border = ButtonDefaults.outlinedButtonBorder.copy()
                        ) {
                            Icon(Icons.Default.Message, null, Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Contacter")
                        }
                        Button(
                            onClick = { /* add to cart */ },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = SrilokGold, contentColor = SrilokBlack),
                            enabled = p.quantity > 0
                        ) {
                            Icon(Icons.Default.AddShoppingCart, null, Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (p.quantity > 0) "Acheter" else "Épuisé")
                        }
                    }
                }
            }
        } ?: Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = SrilokGold)
        }
    }
}

@Composable
fun InfoChip(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String) {
    Surface(shape = RoundedCornerShape(20.dp), color = SrilokSurface2) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = SrilokGoldDark, modifier = Modifier.size(14.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, color = SrilokOnSurfaceMuted)
        }
    }
}
