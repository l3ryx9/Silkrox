package com.srilok.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.srilok.app.data.repository.WalletRepository
import com.srilok.app.domain.model.Transaction
import com.srilok.app.domain.model.Wallet
import com.srilok.app.util.Result
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class WalletViewModel @Inject constructor(private val repo: WalletRepository) : ViewModel() {

    private val _wallet = MutableStateFlow<Wallet?>(null)
    val wallet: StateFlow<Wallet?> = _wallet.asStateFlow()

    private val _paymentStatus = MutableStateFlow<com.srilok.app.data.remote.dto.PaymentStatusDto?>(null)
    val paymentStatus: StateFlow<com.srilok.app.data.remote.dto.PaymentStatusDto?> = _paymentStatus.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    init { loadWallet() }

    fun loadWallet() = viewModelScope.launch {
        _isLoading.value = true
        when (val result = repo.getWallet()) {
            is Result.Success -> _wallet.value = result.data
            else -> _error.value = result.errorMessage()
        }
        _isLoading.value = false
    }

    fun pollPaymentStatus(orderId: String) = viewModelScope.launch {
        while (true) {
            when (val result = repo.getPaymentStatus(orderId)) {
                is Result.Success -> {
                    _paymentStatus.value = result.data
                    if (result.data.confirmations >= result.data.requiredConfirmations) break
                }
                else -> break
            }
            delay(30_000)
        }
    }
}
