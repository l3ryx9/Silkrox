package com.srilok.app.di

import com.srilok.app.data.repository.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object RepositoryModule {
    @Provides @Singleton
    fun provideAuthRepo(
        api: com.srilok.app.data.remote.api.AuthApi,
        userDao: com.srilok.app.data.local.dao.UserDao,
        crypto: com.srilok.app.security.CryptoManager,
        e2ee: com.srilok.app.security.E2EEManager,
        session: com.srilok.app.util.SessionManager,
        device: com.srilok.app.util.DeviceUtil
    ) = AuthRepository(api, userDao, crypto, e2ee, session, device)

    @Provides @Singleton
    fun provideProductRepo(
        api: com.srilok.app.data.remote.api.ProductApi,
        dao: com.srilok.app.data.local.dao.ProductDao,
        gson: com.google.gson.Gson
    ) = ProductRepository(api, dao, gson)

    @Provides @Singleton
    fun provideOrderRepo(
        api: com.srilok.app.data.remote.api.OrderApi,
        dao: com.srilok.app.data.local.dao.OrderDao
    ) = OrderRepository(api, dao)

    @Provides @Singleton
    fun provideWalletRepo(
        api: com.srilok.app.data.remote.api.WalletApi,
        dao: com.srilok.app.data.local.dao.TransactionDao
    ) = WalletRepository(api, dao)

    @Provides @Singleton
    fun provideMessageRepo(
        api: com.srilok.app.data.remote.api.MessageApi,
        msgDao: com.srilok.app.data.local.dao.MessageDao,
        convDao: com.srilok.app.data.local.dao.ConversationDao,
        e2ee: com.srilok.app.security.E2EEManager,
        crypto: com.srilok.app.security.CryptoManager,
        session: com.srilok.app.util.SessionManager
    ) = MessageRepository(api, msgDao, convDao, e2ee, crypto, session)
}
