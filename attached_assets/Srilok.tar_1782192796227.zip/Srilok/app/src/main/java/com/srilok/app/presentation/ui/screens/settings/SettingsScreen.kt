package com.srilok.app.presentation.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.srilok.app.presentation.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(navController: NavController) {
    var autoLock by remember { mutableStateOf(true) }
    var notifications by remember { mutableStateOf(true) }
    var biometrics by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = SrilokBlack,
        topBar = {
            TopAppBar(
                title = { Text("Paramètres", color = SrilokOnSurface) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SrilokSurface),
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Icon(Icons.Default.ArrowBack, null, tint = SrilokGold) } }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionHeader("Sécurité")
            SettingsToggle(Icons.Default.LockClock, "Verrouillage auto (15 min)", autoLock) { autoLock = it }
            SettingsToggle(Icons.Default.Fingerprint, "Authentification biométrique", biometrics) { biometrics = it }
            SettingsItem(Icons.Default.VpnKey, "Changer le mot de passe") {}
            SettingsItem(Icons.Default.Key, "Voir ma clé publique E2EE") {}

            SectionHeader("Notifications")
            SettingsToggle(Icons.Default.Notifications, "Notifications de paiement", notifications) { notifications = it }

            SectionHeader("Application")
            SettingsItem(Icons.Default.Info, "Version 1.0.0") {}
            SettingsItem(Icons.Default.Shield, "Politique de confidentialité") {}
            SettingsItem(Icons.Default.BugReport, "Rapport de sécurité") {}
        }
    }
}

@Composable
fun SectionHeader(title: String) {
    Text(title, style = MaterialTheme.typography.labelLarge, color = SrilokGold, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))
}

@Composable
fun SettingsToggle(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, checked: Boolean, onToggle: (Boolean) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = SrilokSurface), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(icon, null, tint = SrilokGold, modifier = Modifier.size(20.dp))
                Text(label, style = MaterialTheme.typography.bodyMedium, color = SrilokOnSurface)
            }
            Switch(checked = checked, onCheckedChange = onToggle, colors = SwitchDefaults.colors(checkedThumbColor = SrilokBlack, checkedTrackColor = SrilokGold, uncheckedTrackColor = SrilokSurface3))
        }
    }
}

@Composable
fun SettingsItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = SrilokSurface), modifier = Modifier.fillMaxWidth(), onClick = onClick) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = SrilokGold, modifier = Modifier.size(20.dp))
                Text(label, style = MaterialTheme.typography.bodyMedium, color = SrilokOnSurface)
            }
            Icon(Icons.Default.ChevronRight, null, tint = SrilokOnSurfaceMuted, modifier = Modifier.size(18.dp))
        }
    }
}
