package com.srilok.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.srilok.app.data.repository.OrderRepository
import com.srilok.app.domain.model.Order
import com.srilok.app.util.Result
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class OrderViewModel @Inject constructor(private val repo: OrderRepository) : ViewModel() {

    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _newOrder = MutableStateFlow<Order?>(null)
    val newOrder: StateFlow<Order?> = _newOrder.asStateFlow()

    init { sync() }

    fun sync() = viewModelScope.launch {
        _isLoading.value = true
        repo.syncOrders()
        _isLoading.value = false
    }

    fun createOrder(productId: String, quantity: Int) = viewModelScope.launch {
        _isLoading.value = true
        when (val result = repo.createOrder(productId, quantity)) {
            is Result.Success -> _newOrder.value = result.data
            else -> _error.value = result.errorMessage()
        }
        _isLoading.value = false
    }

    fun cancelOrder(orderId: String) = viewModelScope.launch {
        when (val result = repo.cancelOrder(orderId)) {
            is Result.Success -> sync()
            else -> _error.value = result.errorMessage()
        }
    }
}
