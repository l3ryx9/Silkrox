package com.srilok.app.data.remote.dto

import com.google.gson.annotations.SerializedName

data class MessageDto(
    @SerializedName("id") val id: String,
    @SerializedName("conversation_id") val conversationId: String,
    @SerializedName("sender_id") val senderId: String,
    @SerializedName("encrypted_content") val encryptedContent: String,
    @SerializedName("iv") val iv: String,
    @SerializedName("is_read") val isRead: Boolean,
    @SerializedName("timestamp") val timestamp: Long
)

data class ConversationDto(
    @SerializedName("id") val id: String,
    @SerializedName("participant_ids") val participantIds: List<String>,
    @SerializedName("last_message_timestamp") val lastMessageTimestamp: Long?,
    @SerializedName("unread_count") val unreadCount: Int
)

data class SendMessageRequest(
    @SerializedName("conversation_id") val conversationId: String,
    @SerializedName("encrypted_content") val encryptedContent: String,
    @SerializedName("iv") val iv: String,
    @SerializedName("recipient_id") val recipientId: String
)

data class KeyExchangeRequest(
    @SerializedName("user_id") val userId: String,
    @SerializedName("public_key") val publicKey: String,
    @SerializedName("ephemeral_public_key") val ephemeralPublicKey: String
)

data class KeyExchangeResponse(
    @SerializedName("recipient_public_key") val recipientPublicKey: String,
    @SerializedName("recipient_ephemeral_public_key") val recipientEphemeralPublicKey: String
)
