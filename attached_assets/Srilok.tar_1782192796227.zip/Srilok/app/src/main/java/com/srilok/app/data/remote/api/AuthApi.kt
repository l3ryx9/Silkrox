package com.srilok.app.data.remote.api

import com.srilok.app.data.remote.dto.*
import retrofit2.Response
import retrofit2.http.*

interface AuthApi {
    @POST("auth/register") suspend fun register(@Body request: RegisterRequest): Response<AuthResponse>
    @POST("auth/login") suspend fun login(@Body request: LoginRequest): Response<AuthResponse>
    @POST("auth/refresh") suspend fun refresh(@Body request: RefreshTokenRequest): Response<AuthResponse>
    @POST("auth/logout") suspend fun logout(): Response<Unit>
    @GET("auth/captcha") suspend fun getCaptcha(): Response<Map<String, String>>
    @POST("auth/check-password-strength") suspend fun checkPasswordStrength(@Body body: Map<String, String>): Response<PasswordStrengthResponse>
}
