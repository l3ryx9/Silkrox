package com.srilok.app.presentation.ui.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.srilok.app.presentation.navigation.Screen
import com.srilok.app.presentation.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(navController: NavController) {
    Scaffold(
        containerColor = SrilokBlack,
        topBar = {
            TopAppBar(
                title = { Text("Administration", color = SrilokGold, fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SrilokSurface),
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Icon(Icons.Default.ArrowBack, null, tint = SrilokGold) } }
            )
        }
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item { Text("Tableau de bord", style = MaterialTheme.typography.titleLarge, color = SrilokOnSurface) }

            item {
                val stats = listOf(
                    Triple(Icons.Default.People, "Utilisateurs", "—"),
                    Triple(Icons.Default.Storefront, "Annonces", "—"),
                    Triple(Icons.Default.ShoppingBag, "Commandes", "—"),
                    Triple(Icons.Default.AccountBalanceWallet, "Revenus (BTC)", "—")
                )
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    stats.chunked(2).forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            row.forEach { (icon, label, value) ->
                                AdminStatCard(icon, label, value, Modifier.weight(1f))
                            }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }

            item { Text("Navigation rapide", style = MaterialTheme.typography.titleMedium, color = SrilokGold) }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    AdminNavItem(Icons.Default.ShoppingBag, "Gestion des commandes", "Voir et gérer toutes les commandes") { navController.navigate(Screen.AdminOrders.route) }
                    AdminNavItem(Icons.Default.People, "Gestion des utilisateurs", "Voir et modérer les comptes") { navController.navigate(Screen.AdminUsers.route) }
                    AdminNavItem(Icons.Default.Storefront, "Gestion des annonces", "Créer, modifier, archiver") { navController.navigate(Screen.AdminProducts.route) }
                    AdminNavItem(Icons.Default.Campaign, "Annonces système", "Publier des messages officiels") { navController.navigate(Screen.AdminAnnouncements.route) }
                }
            }
        }
    }
}

@Composable
fun AdminStatCard(icon: ImageVector, label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = SrilokSurface), shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = SrilokGold, modifier = Modifier.size(24.dp))
            Text(value, style = MaterialTheme.typography.headlineSmall, color = SrilokGold, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelSmall, color = SrilokOnSurfaceMuted)
        }
    }
}

@Composable
fun AdminNavItem(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = SrilokSurface), onClick = onClick) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Surface(shape = RoundedCornerShape(10.dp), color = SrilokGoldDark.copy(0.3f)) {
                Icon(icon, null, tint = SrilokGold, modifier = Modifier.padding(10.dp).size(22.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, color = SrilokOnSurface)
                Text(subtitle, style = MaterialTheme.typography.labelSmall, color = SrilokOnSurfaceMuted)
            }
            Icon(Icons.Default.ChevronRight, null, tint = SrilokOnSurfaceMuted)
        }
    }
}
