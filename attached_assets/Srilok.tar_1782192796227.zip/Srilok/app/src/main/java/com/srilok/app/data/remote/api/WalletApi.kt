package com.srilok.app.data.remote.api

import com.srilok.app.data.remote.dto.*
import retrofit2.Response
import retrofit2.http.*

interface WalletApi {
    @GET("wallet") suspend fun getWallet(): Response<WalletDto>
    @GET("wallet/transactions") suspend fun getTransactions(): Response<List<TransactionDto>>
    @GET("wallet/payment-status/{orderId}") suspend fun getPaymentStatus(@Path("orderId") orderId: String): Response<PaymentStatusDto>
    @GET("wallet/address") suspend fun getAddress(): Response<Map<String, String>>
}
