package com.srilok.app.data.remote.dto

import com.google.gson.annotations.SerializedName

data class WalletDto(
    @SerializedName("address") val address: String,
    @SerializedName("balance_btc") val balanceBtc: Double,
    @SerializedName("balance_usd") val balanceUsd: Double
)

data class TransactionDto(
    @SerializedName("tx_hash") val txHash: String,
    @SerializedName("wallet_address") val walletAddress: String,
    @SerializedName("amount") val amount: Double,
    @SerializedName("confirmations") val confirmations: Int,
    @SerializedName("type") val type: String,
    @SerializedName("timestamp") val timestamp: Long
)

data class PaymentStatusDto(
    @SerializedName("order_id") val orderId: String,
    @SerializedName("status") val status: String,
    @SerializedName("tx_hash") val txHash: String?,
    @SerializedName("confirmations") val confirmations: Int,
    @SerializedName("required_confirmations") val requiredConfirmations: Int,
    @SerializedName("amount_btc") val amountBtc: Double,
    @SerializedName("payment_address") val paymentAddress: String
)
