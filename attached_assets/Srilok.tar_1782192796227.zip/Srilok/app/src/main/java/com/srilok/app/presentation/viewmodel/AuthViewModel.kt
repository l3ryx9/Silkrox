package com.srilok.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.srilok.app.data.repository.AuthRepository
import com.srilok.app.util.Result
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AuthUiState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val success: Boolean = false
)

@HiltViewModel
class AuthViewModel @Inject constructor(private val authRepository: AuthRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    private val _isLoggedIn = MutableStateFlow(authRepository.isLoggedIn())
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _username = MutableStateFlow("")
    val username: StateFlow<String> = _username.asStateFlow()

    private val _password = MutableStateFlow("")
    val password: StateFlow<String> = _password.asStateFlow()

    private val _passwordScore = MutableStateFlow(0)
    val passwordScore: StateFlow<Int> = _passwordScore.asStateFlow()

    fun onUsernameChange(v: String) { _username.value = v }
    fun onPasswordChange(v: String) {
        _password.value = v
        _passwordScore.value = evaluatePasswordStrength(v)
    }

    fun login() = viewModelScope.launch {
        _uiState.value = AuthUiState(isLoading = true)
        when (val result = authRepository.login(_username.value.trim(), _password.value)) {
            is Result.Success -> { _isLoggedIn.value = true; _uiState.value = AuthUiState(success = true) }
            else -> _uiState.value = AuthUiState(error = result.errorMessage())
        }
    }

    fun register(captchaToken: String) = viewModelScope.launch {
        _uiState.value = AuthUiState(isLoading = true)
        when (val result = authRepository.register(_username.value.trim(), _password.value, captchaToken)) {
            is Result.Success -> { _isLoggedIn.value = true; _uiState.value = AuthUiState(success = true) }
            else -> _uiState.value = AuthUiState(error = result.errorMessage())
        }
    }

    fun logout() = viewModelScope.launch {
        authRepository.logout()
        _isLoggedIn.value = false
        _uiState.value = AuthUiState()
    }

    fun clearError() { _uiState.value = _uiState.value.copy(error = null) }

    private fun evaluatePasswordStrength(pw: String): Int {
        var score = 0
        if (pw.length >= 8) score++
        if (pw.length >= 12) score++
        if (pw.any { it.isUpperCase() }) score++
        if (pw.any { it.isDigit() }) score++
        if (pw.any { "!@#\$%^&*()_+-=[]{}|;':\",./<>?".contains(it) }) score++
        return score
    }
}
