package com.srilok.app.data.repository

import android.util.Base64
import com.srilok.app.data.local.dao.ConversationDao
import com.srilok.app.data.local.dao.MessageDao
import com.srilok.app.data.local.entities.ConversationEntity
import com.srilok.app.data.local.entities.MessageEntity
import com.srilok.app.data.remote.api.MessageApi
import com.srilok.app.data.remote.dto.KeyExchangeRequest
import com.srilok.app.data.remote.dto.SendMessageRequest
import com.srilok.app.domain.model.Message
import com.srilok.app.security.CryptoManager
import com.srilok.app.security.E2EEManager
import com.srilok.app.util.Result
import com.srilok.app.util.SessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.security.KeyFactory
import java.security.spec.X509EncodedKeySpec
import java.time.Instant
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MessageRepository @Inject constructor(
    private val messageApi: MessageApi,
    private val messageDao: MessageDao,
    private val conversationDao: ConversationDao,
    private val e2eeManager: E2EEManager,
    private val cryptoManager: CryptoManager,
    private val sessionManager: SessionManager
) {
    fun getMessages(convId: String): Flow<List<Message>> =
        messageDao.getMessages(convId).map { list ->
            list.map { Message(it.id, it.conversationId, it.senderId, it.encryptedContent, it.iv, it.isRead, Instant.ofEpochMilli(it.timestamp)) }
        }

    suspend fun sendMessage(conversationId: String, plaintext: String, recipientId: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val conv = conversationDao.getConversation(conversationId) ?: return@withContext Result.Error(404, "Conversation not found")
                val sessionKey = deriveSessionKey(conv)
                val encrypted = e2eeManager.encryptMessage(plaintext, sessionKey)
                val iv = encrypted.copyOfRange(0, 12)
                val ciphertext = encrypted.copyOfRange(12, encrypted.size)
                val request = SendMessageRequest(
                    conversationId,
                    Base64.encodeToString(ciphertext, Base64.NO_WRAP),
                    Base64.encodeToString(iv, Base64.NO_WRAP),
                    recipientId
                )
                val response = messageApi.sendMessage(request)
                if (response.isSuccessful) Result.Success(Unit) else Result.Error(response.code(), response.message())
            } catch (e: Exception) { Result.Exception(e) }
        }

    suspend fun initiateKeyExchange(recipientId: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val ephemeral = e2eeManager.generateEphemeralKeyPair()
            val myPublicKeyBase64 = sessionManager.getPublicKey()
            val request = KeyExchangeRequest(
                recipientId,
                myPublicKeyBase64 ?: "",
                Base64.encodeToString(e2eeManager.publicKeyToBytes(ephemeral.public), Base64.NO_WRAP)
            )
            val response = messageApi.exchangeKeys(request)
            if (response.isSuccessful) {
                val body = response.body()!!
                val recipientPubKeyBytes = Base64.decode(body.recipientPublicKey, Base64.NO_WRAP)
                val recipientEphPubKeyBytes = Base64.decode(body.recipientEphemeralPublicKey, Base64.NO_WRAP)
                val keyFactory = KeyFactory.getInstance("EC")
                val recipientPubKey = keyFactory.generatePublic(X509EncodedKeySpec(recipientPubKeyBytes))
                val shared1 = e2eeManager.computeSharedSecret(ephemeral.private, recipientPubKey)
                val convId = "${ sessionManager.getUserId() }-$recipientId"
                val sessionKeySpec = e2eeManager.deriveSessionKey(shared1)
                val sessionKeyEncrypted = cryptoManager.encrypt(sessionKeySpec.encoded)
                conversationDao.upsert(ConversationEntity(convId, com.google.gson.Gson().toJson(listOf(sessionManager.getUserId(), recipientId)), null, 0, sessionKeyEncrypted))
                Result.Success(convId)
            } else Result.Error(response.code(), response.message())
        } catch (e: Exception) { Result.Exception(e) }
    }

    private fun deriveSessionKey(conv: ConversationEntity): javax.crypto.spec.SecretKeySpec {
        val decrypted = cryptoManager.decrypt(conv.sessionKeyEncrypted)
        return javax.crypto.spec.SecretKeySpec(decrypted, "AES")
    }

    suspend fun syncMessages(convId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val response = messageApi.getMessages(convId)
            if (response.isSuccessful) {
                val entities = response.body()!!.map {
                    MessageEntity(it.id, it.conversationId, it.senderId,
                        Base64.decode(it.encryptedContent, Base64.NO_WRAP),
                        Base64.decode(it.iv, Base64.NO_WRAP),
                        it.isRead, it.timestamp)
                }
                messageDao.insertMessages(entities)
                Result.Success(Unit)
            } else Result.Error(response.code(), response.message())
        } catch (e: Exception) { Result.Exception(e) }
    }
}
