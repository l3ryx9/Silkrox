package com.srilok.app.data.local.dao

import androidx.room.*
import com.srilok.app.data.local.entities.ProductEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY createdAt DESC") fun getAllProducts(): Flow<List<ProductEntity>>
    @Query("SELECT * FROM products WHERE id = :id LIMIT 1") fun getProduct(id: String): Flow<ProductEntity?>
    @Query("SELECT * FROM products WHERE categoryId = :categoryId") fun getByCategory(categoryId: String): Flow<List<ProductEntity>>
    @Query("SELECT * FROM products WHERE title LIKE '%' || :query || '%'") fun search(query: String): Flow<List<ProductEntity>>
    @Query("SELECT * FROM products WHERE featured = 1 LIMIT 10") fun getFeatured(): Flow<List<ProductEntity>>
    @Query("SELECT * FROM products WHERE status = 'ACTIVE' ORDER BY orderCount DESC LIMIT 20") fun getPopular(): Flow<List<ProductEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(products: List<ProductEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(product: ProductEntity)
    @Update suspend fun update(product: ProductEntity)
    @Query("DELETE FROM products WHERE id = :id") suspend fun delete(id: String)
    @Query("DELETE FROM products") suspend fun clearAll()
}
