package com.srilok.app.presentation.ui.screens.wallet

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.srilok.app.domain.model.Transaction
import com.srilok.app.domain.model.TransactionType
import com.srilok.app.presentation.ui.theme.*
import com.srilok.app.presentation.viewmodel.WalletViewModel
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WalletScreen(navController: NavController, vm: WalletViewModel = hiltViewModel()) {
    val wallet by vm.wallet.collectAsState()
    val isLoading by vm.isLoading.collectAsState()

    Scaffold(
        containerColor = SrilokBlack,
        topBar = {
            TopAppBar(
                title = { Text("Portefeuille Bitcoin", color = SrilokOnSurface) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SrilokSurface),
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, null, tint = SrilokGold)
                    }
                },
                actions = {
                    IconButton(onClick = { vm.loadWallet() }) {
                        Icon(Icons.Default.Refresh, null, tint = SrilokGold)
                    }
                }
            )
        }
    ) { padding ->
        if (isLoading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = SrilokGold)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(padding), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                item {
                    BalanceCard(
                        address = wallet?.address ?: "—",
                        balance = wallet?.balanceBtc ?: 0.0,
                        modifier = Modifier.padding(16.dp)
                    )
                }
                item {
                    Text("Transactions", style = MaterialTheme.typography.titleMedium, color = SrilokGold, modifier = Modifier.padding(horizontal = 16.dp))
                }
                items(wallet?.transactions ?: emptyList()) { tx ->
                    TransactionItem(tx = tx, modifier = Modifier.padding(horizontal = 16.dp))
                }
                if (wallet?.transactions.isNullOrEmpty()) {
                    item {
                        Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                            Text("Aucune transaction", color = SrilokOnSurfaceMuted, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }
}

@Composable
fun BalanceCard(address: String, balance: Double, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(Brush.verticalGradient(listOf(SrilokGoldDark, SrilokSurface2)))
    ) {
        Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.AccountBalanceWallet, null, tint = SrilokGold, modifier = Modifier.size(24.dp))
                Text("Solde disponible", style = MaterialTheme.typography.labelLarge, color = SrilokOnSurfaceMuted)
            }
            Text("%.8f BTC".format(balance), style = MaterialTheme.typography.displaySmall, color = SrilokGold, fontWeight = FontWeight.Bold)
            Divider(color = SrilokGoldDark.copy(alpha = 0.5f))
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Adresse Bitcoin", style = MaterialTheme.typography.labelSmall, color = SrilokOnSurfaceMuted)
                Text(address, style = MaterialTheme.typography.bodySmall, color = SrilokOnSurface, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
            }
        }
    }
}

@Composable
fun TransactionItem(tx: Transaction, modifier: Modifier = Modifier) {
    Card(modifier = modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = SrilokSurface), shape = RoundedCornerShape(10.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(8.dp), color = if (tx.type == TransactionType.RECEIVED) SrilokSuccess.copy(0.15f) else SrilokError.copy(0.15f)) {
                    Icon(
                        if (tx.type == TransactionType.RECEIVED) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                        null, tint = if (tx.type == TransactionType.RECEIVED) SrilokSuccess else SrilokError,
                        modifier = Modifier.padding(8.dp).size(18.dp)
                    )
                }
                Column {
                    Text(if (tx.type == TransactionType.RECEIVED) "Reçu" else "Envoyé", style = MaterialTheme.typography.labelLarge, color = SrilokOnSurface)
                    Text("${tx.confirmations} confirmations", style = MaterialTheme.typography.labelSmall, color = SrilokOnSurfaceMuted)
                    Text(tx.timestamp.atZone(java.time.ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("dd/MM/yy HH:mm")),
                        style = MaterialTheme.typography.labelSmall, color = SrilokOnSurfaceMuted)
                }
            }
            Text(
                "${if (tx.type == TransactionType.RECEIVED) "+" else "-"}%.8f".format(tx.amount),
                style = MaterialTheme.typography.labelLarge,
                color = if (tx.type == TransactionType.RECEIVED) SrilokSuccess else SrilokError,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
