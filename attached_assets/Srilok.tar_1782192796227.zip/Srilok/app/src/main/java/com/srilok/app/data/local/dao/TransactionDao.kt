package com.srilok.app.data.local.dao

import androidx.room.*
import com.srilok.app.data.local.entities.TransactionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions WHERE walletAddress = :address ORDER BY timestamp DESC")
    fun getTransactions(address: String): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(txs: List<TransactionEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(tx: TransactionEntity)
    @Query("DELETE FROM transactions WHERE walletAddress = :address") suspend fun clear(address: String)
}
