package com.srilok.app.presentation.ui.screens.messaging

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.srilok.app.presentation.ui.theme.*
import com.srilok.app.presentation.viewmodel.MessageViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConversationScreen(navController: NavController, convId: String, vm: MessageViewModel = hiltViewModel()) {
    val messages by vm.messages.collectAsState()
    val draft by vm.draft.collectAsState()
    val isLoading by vm.isLoading.collectAsState()
    val listState = rememberLazyListState()

    LaunchedEffect(convId) { vm.loadConversation(convId) }
    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1) }

    Scaffold(
        containerColor = SrilokBlack,
        topBar = {
            TopAppBar(
                title = { Text("Conversation", color = SrilokOnSurface) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SrilokSurface),
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, null, tint = SrilokGold)
                    }
                },
                actions = {
                    Icon(Icons.Default.Lock, null, tint = SrilokGold, modifier = Modifier.padding(end = 16.dp).size(16.dp))
                }
            )
        },
        bottomBar = {
            Surface(color = SrilokSurface, shadowElevation = 8.dp) {
                Row(
                    Modifier.padding(12.dp).navigationBarsPadding(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = draft,
                        onValueChange = vm::onDraftChange,
                        placeholder = { Text("Message chiffré...", color = SrilokOnSurfaceMuted) },
                        colors = goldOutlinedColors(),
                        modifier = Modifier.weight(1f),
                        maxLines = 4
                    )
                    IconButton(
                        onClick = { vm.sendMessage("recipient_id") },
                        enabled = draft.isNotBlank() && !isLoading,
                        modifier = Modifier.background(SrilokGold, RoundedCornerShape(12.dp)).size(48.dp)
                    ) {
                        Icon(Icons.Default.Send, null, tint = SrilokBlack)
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            items(messages) { msg ->
                val isMine = false
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isMine) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        shape = RoundedCornerShape(
                            topStart = 16.dp, topEnd = 16.dp,
                            bottomStart = if (isMine) 16.dp else 4.dp,
                            bottomEnd = if (isMine) 4.dp else 16.dp
                        ),
                        color = if (isMine) SrilokGoldDark else SrilokSurface2,
                        modifier = Modifier.widthIn(max = 280.dp)
                    ) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("[chiffré]", color = SrilokOnSurface, style = MaterialTheme.typography.bodyMedium, fontFamily = FontFamily.Monospace)
                            if (msg.isRead) Icon(Icons.Default.DoneAll, null, tint = SrilokGold, modifier = Modifier.size(12.dp).align(Alignment.End))
                        }
                    }
                }
            }
        }
    }
}

@Composable fun goldOutlinedColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = SrilokGold, unfocusedBorderColor = SrilokSurface3,
    focusedLabelColor = SrilokGold, unfocusedLabelColor = SrilokOnSurfaceMuted,
    cursorColor = SrilokGold, focusedTextColor = SrilokOnSurface, unfocusedTextColor = SrilokOnSurface,
    focusedContainerColor = SrilokSurface, unfocusedContainerColor = SrilokSurface,
)
