package com.srilok.app.presentation.ui.screens.auth

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.srilok.app.presentation.navigation.Screen
import com.srilok.app.presentation.ui.theme.*
import com.srilok.app.presentation.viewmodel.AuthViewModel

@Composable
fun RegisterScreen(navController: NavController, vm: AuthViewModel = hiltViewModel()) {
    val uiState by vm.uiState.collectAsState()
    val username by vm.username.collectAsState()
    val password by vm.password.collectAsState()
    val passwordScore by vm.passwordScore.collectAsState()
    var passwordVisible by remember { mutableStateOf(false) }

    LaunchedEffect(uiState.success) {
        if (uiState.success) navController.navigate(Screen.Home.route) { popUpTo(0) }
    }

    Box(Modifier.fillMaxSize().background(SrilokBlack)) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(Modifier.height(32.dp))
            Text("SRILOK", style = MaterialTheme.typography.displayMedium, color = SrilokGold)
            Text("Créer un compte", style = MaterialTheme.typography.bodyMedium, color = SrilokOnSurfaceMuted)
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(
                value = username, onValueChange = vm::onUsernameChange,
                label = { Text("Identifiant unique") },
                leadingIcon = { Icon(Icons.Default.Person, null, tint = SrilokGold) },
                singleLine = true, colors = goldOutlinedColors(), modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = password, onValueChange = vm::onPasswordChange,
                label = { Text("Mot de passe") },
                leadingIcon = { Icon(Icons.Default.Lock, null, tint = SrilokGold) },
                trailingIcon = {
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility, null, tint = SrilokOnSurfaceMuted)
                    }
                },
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                singleLine = true, colors = goldOutlinedColors(), modifier = Modifier.fillMaxWidth()
            )

            PasswordStrengthBar(score = passwordScore)

            AnimatedVisibility(uiState.error != null) {
                Card(colors = CardDefaults.cardColors(containerColor = SrilokError.copy(0.15f)), modifier = Modifier.fillMaxWidth()) {
                    Text(uiState.error ?: "", color = SrilokError, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
                }
            }

            Button(
                onClick = { vm.register("captcha_placeholder") },
                enabled = !uiState.isLoading && username.isNotBlank() && password.length >= 8,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SrilokGold, contentColor = SrilokBlack)
            ) {
                if (uiState.isLoading) CircularProgressIndicator(color = SrilokBlack, modifier = Modifier.size(20.dp))
                else Text("Créer mon compte", style = MaterialTheme.typography.labelLarge)
            }

            TextButton(onClick = { navController.popBackStack() }) {
                Text("Déjà inscrit ? Se connecter", color = SrilokGold, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun PasswordStrengthBar(score: Int) {
    val color = when {
        score <= 1 -> SrilokError
        score <= 3 -> SrilokWarning
        else -> SrilokSuccess
    }
    val label = when {
        score <= 1 -> "Faible"
        score <= 3 -> "Moyen"
        score == 4 -> "Fort"
        else -> "Très fort"
    }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        LinearProgressIndicator(
            progress = { score / 5f },
            modifier = Modifier.fillMaxWidth().height(6.dp),
            color = color,
            trackColor = SrilokSurface3
        )
        Text(label, color = color, style = MaterialTheme.typography.labelSmall)
    }
}
