package com.srilok.app.presentation.ui.screens.auth

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.srilok.app.presentation.navigation.Screen
import com.srilok.app.presentation.ui.theme.*
import com.srilok.app.presentation.viewmodel.AuthViewModel

@Composable
fun LoginScreen(navController: NavController, vm: AuthViewModel = hiltViewModel()) {
    val uiState by vm.uiState.collectAsState()
    val username by vm.username.collectAsState()
    val password by vm.password.collectAsState()
    var passwordVisible by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current

    LaunchedEffect(uiState.success) {
        if (uiState.success) navController.navigate(Screen.Home.route) { popUpTo(0) }
    }

    Box(
        modifier = Modifier.fillMaxSize().background(SrilokBlack),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Spacer(Modifier.height(32.dp))

            Text("SRILOK", style = MaterialTheme.typography.displayMedium, color = SrilokGold)
            Text("Connexion sécurisée", style = MaterialTheme.typography.bodyMedium, color = SrilokOnSurfaceMuted)

            Spacer(Modifier.height(16.dp))

            OutlinedTextField(
                value = username,
                onValueChange = vm::onUsernameChange,
                label = { Text("Identifiant") },
                leadingIcon = { Icon(Icons.Default.Person, null, tint = SrilokGold) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
                colors = goldOutlinedColors(),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = password,
                onValueChange = vm::onPasswordChange,
                label = { Text("Mot de passe") },
                leadingIcon = { Icon(Icons.Default.Lock, null, tint = SrilokGold) },
                trailingIcon = {
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility, null, tint = SrilokOnSurfaceMuted)
                    }
                },
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { vm.login() }),
                colors = goldOutlinedColors(),
                modifier = Modifier.fillMaxWidth()
            )

            AnimatedVisibility(uiState.error != null) {
                Card(colors = CardDefaults.cardColors(containerColor = SrilokError.copy(alpha = 0.15f)), modifier = Modifier.fillMaxWidth()) {
                    Text(uiState.error ?: "", color = SrilokError, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
                }
            }

            Button(
                onClick = { vm.login() },
                enabled = !uiState.isLoading && username.isNotBlank() && password.isNotBlank(),
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SrilokGold, contentColor = SrilokBlack)
            ) {
                if (uiState.isLoading) CircularProgressIndicator(color = SrilokBlack, modifier = Modifier.size(20.dp))
                else Text("Se connecter", style = MaterialTheme.typography.labelLarge)
            }

            TextButton(onClick = { navController.navigate(Screen.Register.route) }) {
                Text("Pas encore de compte ? S'inscrire", color = SrilokGold, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun goldOutlinedColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = SrilokGold,
    unfocusedBorderColor = SrilokSurface3,
    focusedLabelColor = SrilokGold,
    unfocusedLabelColor = SrilokOnSurfaceMuted,
    cursorColor = SrilokGold,
    focusedTextColor = SrilokOnSurface,
    unfocusedTextColor = SrilokOnSurface,
    focusedContainerColor = SrilokSurface,
    unfocusedContainerColor = SrilokSurface,
)
