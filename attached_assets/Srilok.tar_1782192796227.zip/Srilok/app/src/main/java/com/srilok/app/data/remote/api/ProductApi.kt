package com.srilok.app.data.remote.api

import com.srilok.app.data.remote.dto.*
import okhttp3.MultipartBody
import retrofit2.Response
import retrofit2.http.*

interface ProductApi {
    @GET("products") suspend fun getProducts(@Query("page") page: Int = 1, @Query("per_page") perPage: Int = 20): Response<ProductListResponse>
    @GET("products/{id}") suspend fun getProduct(@Path("id") id: String): Response<ProductDto>
    @GET("products/search") suspend fun search(@Query("q") query: String, @Query("category_id") categoryId: String? = null): Response<ProductListResponse>
    @GET("products/featured") suspend fun getFeatured(): Response<List<ProductDto>>
    @GET("products/popular") suspend fun getPopular(): Response<List<ProductDto>>
    @GET("categories") suspend fun getCategories(): Response<List<CategoryDto>>
    @POST("products") suspend fun createProduct(@Body request: CreateProductRequest): Response<ProductDto>
    @PATCH("products/{id}") suspend fun updateProduct(@Path("id") id: String, @Body request: UpdateProductRequest): Response<ProductDto>
    @DELETE("products/{id}") suspend fun deleteProduct(@Path("id") id: String): Response<Unit>
    @POST("products/{id}/feature") suspend fun featureProduct(@Path("id") id: String): Response<ProductDto>
    @POST("products/{id}/duplicate") suspend fun duplicateProduct(@Path("id") id: String): Response<ProductDto>
    @Multipart
    @POST("media/upload")
    suspend fun uploadImage(@Part file: MultipartBody.Part): Response<Map<String, String>>
}
