package com.srilok.app.security

import com.srilok.app.BuildConfig
import okhttp3.CertificatePinner
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SrilokCertificatePinner @Inject constructor() {

    fun build(): CertificatePinner {
        return CertificatePinner.Builder()
            .add("api.srilok.com", BuildConfig.API_CERT_SHA256)
            .build()
    }
}
