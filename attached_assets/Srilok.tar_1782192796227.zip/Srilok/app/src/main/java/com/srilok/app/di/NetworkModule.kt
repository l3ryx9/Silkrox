package com.srilok.app.di

import com.srilok.app.BuildConfig
import com.srilok.app.data.remote.api.*
import com.srilok.app.security.SrilokCertificatePinner
import com.srilok.app.util.SessionManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides @Singleton
    fun provideOkHttpClient(sessionManager: SessionManager, pinner: SrilokCertificatePinner): OkHttpClient {
        val authInterceptor = Interceptor { chain ->
            val token = sessionManager.getAccessToken()
            val request = chain.request().newBuilder()
                .apply { if (token != null) addHeader("Authorization", "Bearer $token") }
                .addHeader("X-Platform", "android")
                .build()
            sessionManager.updateLastActive()
            chain.proceed(request)
        }
        return OkHttpClient.Builder()
            .certificatePinner(pinner.build())
            .addInterceptor(authInterceptor)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    @Provides @Singleton
    fun provideRetrofit(client: OkHttpClient): Retrofit = Retrofit.Builder()
        .baseUrl(BuildConfig.API_BASE_URL)
        .client(client)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    @Provides @Singleton fun provideAuthApi(r: Retrofit): AuthApi = r.create(AuthApi::class.java)
    @Provides @Singleton fun provideProductApi(r: Retrofit): ProductApi = r.create(ProductApi::class.java)
    @Provides @Singleton fun provideOrderApi(r: Retrofit): OrderApi = r.create(OrderApi::class.java)
    @Provides @Singleton fun provideWalletApi(r: Retrofit): WalletApi = r.create(WalletApi::class.java)
    @Provides @Singleton fun provideMessageApi(r: Retrofit): MessageApi = r.create(MessageApi::class.java)
}
