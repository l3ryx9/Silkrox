package com.srilok.app.presentation.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.srilok.app.domain.model.Product
import com.srilok.app.presentation.navigation.Screen
import com.srilok.app.presentation.ui.theme.*
import com.srilok.app.presentation.viewmodel.AuthViewModel
import com.srilok.app.presentation.viewmodel.ProductViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    navController: NavController,
    productVm: ProductViewModel = hiltViewModel(),
    authVm: AuthViewModel = hiltViewModel()
) {
    val featured by productVm.featured.collectAsState()
    val popular by productVm.popular.collectAsState()
    val isLoading by productVm.isLoading.collectAsState()

    Scaffold(
        containerColor = SrilokBlack,
        topBar = {
            TopAppBar(
                title = { Text("SRILOK", color = SrilokGold, fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SrilokBlack),
                actions = {
                    IconButton(onClick = { navController.navigate(Screen.Search.route) }) {
                        Icon(Icons.Default.Search, null, tint = SrilokGold)
                    }
                    IconButton(onClick = { navController.navigate(Screen.Wallet.route) }) {
                        Icon(Icons.Default.AccountBalanceWallet, null, tint = SrilokGold)
                    }
                    IconButton(onClick = { navController.navigate(Screen.MessagingList.route) }) {
                        Icon(Icons.Default.Message, null, tint = SrilokGold)
                    }
                }
            )
        },
        bottomBar = { SrilokBottomBar(navController) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            item {
                HeroBanner(modifier = Modifier.padding(16.dp))
            }
            item {
                SectionTitle("À la une", onSeeAll = { navController.navigate(Screen.Catalog.route) })
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(featured) { product ->
                        ProductCard(product = product, onClick = { navController.navigate(Screen.ProductDetail.createRoute(product.id)) })
                    }
                }
            }
            item {
                SectionTitle("Les plus populaires", onSeeAll = { navController.navigate(Screen.Catalog.route) })
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(popular) { product ->
                        ProductCard(product = product, onClick = { navController.navigate(Screen.ProductDetail.createRoute(product.id)) })
                    }
                }
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

@Composable
fun HeroBanner(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.fillMaxWidth().height(180.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.horizontalGradient(listOf(SrilokGoldDark, SrilokSurface2))),
        contentAlignment = Alignment.CenterStart
    ) {
        Column(Modifier.padding(24.dp)) {
            Text("Bienvenue", style = MaterialTheme.typography.headlineMedium, color = SrilokGold)
            Text("Découvrez notre sélection exclusive", style = MaterialTheme.typography.bodyMedium, color = SrilokOnSurface)
        }
        Icon(Icons.Default.Stars, null, tint = SrilokGold.copy(alpha = 0.15f),
            modifier = Modifier.align(Alignment.CenterEnd).size(120.dp).padding(16.dp))
    }
}

@Composable
fun SectionTitle(title: String, onSeeAll: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = SrilokOnSurface)
        TextButton(onClick = onSeeAll) { Text("Voir tout", color = SrilokGold, style = MaterialTheme.typography.labelMedium) }
    }
}

@Composable
fun ProductCard(product: Product, onClick: () -> Unit) {
    Card(
        modifier = Modifier.width(160.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = SrilokSurface)
    ) {
        Column {
            Box(Modifier.fillMaxWidth().height(120.dp).background(SrilokSurface2)) {
                if (product.images.isNotEmpty()) {
                    AsyncImage(model = product.images.first(), contentDescription = null,
                        modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    Icon(Icons.Default.Image, null, tint = SrilokOnSurfaceMuted, modifier = Modifier.align(Alignment.Center).size(40.dp))
                }
                if (product.featured) {
                    Surface(Modifier.align(Alignment.TopEnd).padding(6.dp), shape = RoundedCornerShape(4.dp), color = SrilokGold) {
                        Text("★", color = SrilokBlack, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(product.title, style = MaterialTheme.typography.labelLarge, color = SrilokOnSurface, maxLines = 2)
                Text("%.8f BTC".format(product.price), style = MaterialTheme.typography.labelMedium, color = SrilokGold, fontWeight = FontWeight.Bold)
                Text("Stock: ${product.quantity}", style = MaterialTheme.typography.labelSmall, color = SrilokOnSurfaceMuted)
            }
        }
    }
}

@Composable
fun SrilokBottomBar(navController: NavController) {
    NavigationBar(containerColor = SrilokSurface, contentColor = SrilokGold) {
        val items = listOf(
            Triple(Icons.Default.Home, "Accueil", Screen.Home.route),
            Triple(Icons.Default.GridView, "Catalogue", Screen.Catalog.route),
            Triple(Icons.Default.ShoppingCart, "Panier", Screen.Cart.route),
            Triple(Icons.Default.AccountCircle, "Profil", Screen.Profile.route)
        )
        items.forEach { (icon, label, route) ->
            NavigationBarItem(
                icon = { Icon(icon, label) },
                label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                selected = false,
                onClick = { navController.navigate(route) { launchSingleTop = true } },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = SrilokGold,
                    unselectedIconColor = SrilokOnSurfaceMuted,
                    selectedTextColor = SrilokGold,
                    unselectedTextColor = SrilokOnSurfaceMuted,
                    indicatorColor = SrilokGoldDark.copy(alpha = 0.3f)
                )
            )
        }
    }
}
