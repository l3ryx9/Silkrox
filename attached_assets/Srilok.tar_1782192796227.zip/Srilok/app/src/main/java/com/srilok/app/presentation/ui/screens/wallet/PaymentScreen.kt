package com.srilok.app.presentation.ui.screens.wallet

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.srilok.app.presentation.ui.theme.*
import com.srilok.app.presentation.viewmodel.WalletViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentScreen(navController: NavController, orderId: String, vm: WalletViewModel = hiltViewModel()) {
    val paymentStatus by vm.paymentStatus.collectAsState()

    LaunchedEffect(orderId) { vm.pollPaymentStatus(orderId) }

    Scaffold(
        containerColor = SrilokBlack,
        topBar = {
            TopAppBar(
                title = { Text("Paiement Bitcoin", color = SrilokOnSurface) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SrilokSurface),
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, null, tint = SrilokGold)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            paymentStatus?.let { status ->
                StatusBadge(status = status.status)

                val qrBitmap = remember(status.paymentAddress) { generateQr("bitcoin:${status.paymentAddress}?amount=${status.amountBtc}") }
                qrBitmap?.let { bmp ->
                    Box(Modifier.size(220.dp).clip(RoundedCornerShape(16.dp)).background(SrilokOnSurface).padding(12.dp)) {
                        Image(bitmap = bmp.asImageBitmap(), contentDescription = "QR Code", modifier = Modifier.fillMaxSize())
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = SrilokSurface), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        PaymentInfoRow("Montant", "%.8f BTC".format(status.amountBtc))
                        PaymentInfoRow("Adresse", status.paymentAddress, monospace = true)
                        PaymentInfoRow("Confirmations", "${status.confirmations} / ${status.requiredConfirmations}")
                        if (status.txHash != null) PaymentInfoRow("TX Hash", status.txHash, monospace = true)
                    }
                }

                LinearProgressIndicator(
                    progress = { (status.confirmations.toFloat() / status.requiredConfirmations.toFloat()).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color = SrilokGold,
                    trackColor = SrilokSurface3
                )
                Text("${status.confirmations} sur ${status.requiredConfirmations} confirmations requises",
                    style = MaterialTheme.typography.bodySmall, color = SrilokOnSurfaceMuted, textAlign = TextAlign.Center)

            } ?: CircularProgressIndicator(color = SrilokGold)
        }
    }
}

@Composable
fun StatusBadge(status: String) {
    val (color, label) = when (status) {
        "CONFIRMED" -> SrilokSuccess to "Confirmé ✓"
        "PAYMENT_DETECTED" -> SrilokWarning to "Paiement détecté..."
        "PENDING_PAYMENT" -> SrilokOnSurfaceMuted to "En attente de paiement"
        else -> SrilokError to status
    }
    Surface(shape = RoundedCornerShape(20.dp), color = color.copy(alpha = 0.15f)) {
        Text(label, color = color, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun PaymentInfoRow(label: String, value: String, monospace: Boolean = false) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = SrilokOnSurfaceMuted)
        Text(value, style = MaterialTheme.typography.bodySmall, color = SrilokOnSurface,
            fontFamily = if (monospace) FontFamily.Monospace else FontFamily.Default)
    }
}

private fun generateQr(content: String): Bitmap? = try {
    val hints = mapOf(EncodeHintType.MARGIN to 1)
    val bits = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, 512, 512, hints)
    val bmp = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888)
    for (x in 0 until 512) for (y in 0 until 512)
        bmp.setPixel(x, y, if (bits[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
    bmp
} catch (e: Exception) { null }
