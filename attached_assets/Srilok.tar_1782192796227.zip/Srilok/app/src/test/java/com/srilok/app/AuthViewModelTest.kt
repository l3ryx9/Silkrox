package com.srilok.app

import com.srilok.app.data.repository.AuthRepository
import com.srilok.app.presentation.viewmodel.AuthViewModel
import com.srilok.app.util.Result
import io.mockk.coEvery
import io.mockk.every
import io.mockk.mockk
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.*
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class AuthViewModelTest {

    private val testDispatcher = UnconfinedTestDispatcher()
    private lateinit var authRepo: AuthRepository
    private lateinit var vm: AuthViewModel

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
        authRepo = mockk()
        every { authRepo.isLoggedIn() } returns false
        vm = AuthViewModel(authRepo)
    }

    @After
    fun tearDown() { Dispatchers.resetMain() }

    @Test
    fun `login success sets isLoggedIn true`() = runTest {
        coEvery { authRepo.login(any(), any()) } returns Result.Success(Unit)
        vm.onUsernameChange("testuser")
        vm.onPasswordChange("P@ssw0rd123")
        vm.login()
        assertTrue(vm.isLoggedIn.value)
    }

    @Test
    fun `login error sets error state`() = runTest {
        coEvery { authRepo.login(any(), any()) } returns Result.Error(401, "Unauthorized")
        vm.onUsernameChange("testuser")
        vm.onPasswordChange("wrong")
        vm.login()
        assertFalse(vm.isLoggedIn.value)
        assertNotNull(vm.uiState.value.error)
    }

    @Test
    fun `password score weak for short password`() {
        vm.onPasswordChange("abc")
        assertEquals(0, vm.passwordScore.value)
    }

    @Test
    fun `password score strong for complex password`() {
        vm.onPasswordChange("P@ssw0rdSecure!")
        assertTrue(vm.passwordScore.value >= 4)
    }

    @Test
    fun `logout clears session`() = runTest {
        coEvery { authRepo.logout() } returns Result.Success(Unit)
        vm.logout()
        assertFalse(vm.isLoggedIn.value)
    }
}
