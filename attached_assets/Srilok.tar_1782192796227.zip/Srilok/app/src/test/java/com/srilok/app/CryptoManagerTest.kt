package com.srilok.app

import com.srilok.app.security.E2EEManager
import org.junit.Assert.*
import org.junit.Test

class E2EEManagerTest {

    @Test
    fun `generateIdentityKeyPair returns non-null key pair`() {
        val e2ee = E2EEManager(mockk())
        val pair = e2ee.generateIdentityKeyPair()
        assertNotNull(pair.public)
        assertNotNull(pair.private)
    }

    @Test
    fun `encrypt and decrypt message roundtrip`() {
        val e2ee = E2EEManager(mockk())
        val alice = e2ee.generateIdentityKeyPair()
        val bob = e2ee.generateIdentityKeyPair()

        val aliceShared = e2ee.computeSharedSecret(alice.private, bob.public)
        val bobShared = e2ee.computeSharedSecret(bob.private, alice.public)

        val aliceKey = e2ee.deriveSessionKey(aliceShared)
        val bobKey = e2ee.deriveSessionKey(bobShared)

        val message = "Message secret de test"
        val encrypted = e2ee.encryptMessage(message, aliceKey)
        val decrypted = e2ee.decryptMessage(encrypted, bobKey)

        assertEquals(message, decrypted)
    }

    @Test
    fun `shared secrets are equal for both parties`() {
        val e2ee = E2EEManager(mockk())
        val alice = e2ee.generateIdentityKeyPair()
        val bob = e2ee.generateIdentityKeyPair()

        val aliceShared = e2ee.computeSharedSecret(alice.private, bob.public)
        val bobShared = e2ee.computeSharedSecret(bob.private, alice.public)

        assertArrayEquals(aliceShared, bobShared)
    }

    private fun mockk(): com.srilok.app.security.CryptoManager {
        return io.mockk.mockk(relaxed = true)
    }
}
